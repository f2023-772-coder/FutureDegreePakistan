"""Settings page: data management, retraining, app info."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS
import prediction_service
import data_processing
import spark_service


class SettingsPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._status = ctk.StringVar(value="Ready.")
        self._spark_status = ctk.StringVar()
        self._build()
        self._refresh_spark_status()

    def _build(self):
        self.title("Settings", self).pack(anchor="w", pady=(0, 10))

        card = self.card()
        card.pack(fill="x", pady=6)
        ctk.CTkLabel(card, text="Data Management",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 4))

        def btn(text, cmd):
            return ctk.CTkButton(card, text=text, height=36, width=280,
                                 corner_radius=10, fg_color=COLORS["accent"],
                                 hover_color=COLORS["primary"], command=cmd)

        btn("Rebuild datasets from database", self._rebuild_datasets).pack(
            anchor="w", padx=18, pady=4)
        btn("Retrain ML models", self._retrain).pack(anchor="w", padx=18, pady=4)
        btn("Re-seed database (reset to defaults)", self._reseed).pack(
            anchor="w", padx=18, pady=(4, 12))

        spark_card = self.card()
        spark_card.pack(fill="x", pady=6)
        ctk.CTkLabel(spark_card, text="Big Data Engine (PySpark)",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 4))
        ctk.CTkButton(spark_card, text="Train Spark MLlib Models", height=36, width=280,
                      corner_radius=10, fg_color=COLORS["accent"],
                      hover_color=COLORS["primary"],
                      command=self._train_spark).pack(anchor="w", padx=18, pady=4)
        ctk.CTkLabel(spark_card, textvariable=self._spark_status,
                     font=("Segoe UI", 11), text_color=COLORS["muted"],
                     wraplength=1000, justify="left").pack(anchor="w", padx=18, pady=(0, 12))

        ctk.CTkLabel(card, textvariable=self._status, font=("Segoe UI", 11),
                     text_color=COLORS["muted"]).pack(anchor="w", padx=18, pady=(0, 12))

        info = self.card()
        info.pack(fill="x", pady=6)
        ctk.CTkLabel(info, text="About this data",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 4))
        ctk.CTkLabel(info,
                     text="Historical salary and employment series are simulated "
                          "illustrative estimates stored locally in SQLite and CSV "
                          "datasets. To add real Pakistani data later, append rows to "
                          "datasets/salary_data.csv and datasets/employment_data.csv, "
                          "then use 'Retrain ML models'.",
                     font=("Segoe UI", 11), text_color=COLORS["muted"],
                     wraplength=1100, justify="left").pack(anchor="w", padx=18, pady=(0, 14))

    def _rebuild_datasets(self):
        try:
            data_processing.rebuild_datasets()
            self._status.set("Datasets rebuilt successfully.")
        except Exception as e:
            self._status.set(f"Error: {e}")

    def _retrain(self):
        try:
            prediction_service._retrain_models()
            prediction_service._models_loaded = True
            self._status.set("Models retrained and saved.")
        except Exception as e:
            self._status.set(f"Error: {e}")

    def _refresh_spark_status(self):
        try:
            st = spark_service.spark_engine_status()
            self._spark_status.set(
                f"PySpark {'available' if st['available'] else 'NOT installed'} | "
                f"SparkSession {'running' if st['session'] else 'not started'} | "
                f"MLlib models {'trained' if st['models_trained'] else 'not trained'}")
        except Exception as e:
            self._spark_status.set(f"Spark status error: {e}")

    def _train_spark(self):
        try:
            spark = spark_service.get_spark()
            if spark is None:
                self._spark_status.set("PySpark unavailable — install with: pip install pyspark")
                return
            self._spark_status.set("Training Spark MLlib models (this may take a minute)...")
            self.update_idletasks()
            summary = spark_service.train_spark_models(spark, force=True)
            n = sum(len(v) for v in summary.values()) if summary else 0
            self._spark_status.set(f"Spark MLlib training complete — {n} degree models saved.")
        except Exception as e:
            self._spark_status.set(f"Spark training error: {e}")

    def _reseed(self):
        try:
            prediction_service.seed_database(force=True)
            prediction_service._retrain_models()
            prediction_service._models_loaded = True
            self._status.set("Database re-seeded and models retrained.")
        except Exception as e:
            self._status.set(f"Error: {e}")
