"""Career Predictions page: degree + period -> ML prediction report."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS, format_pkr, format_pkr_short
import prediction_service
import charts


class PredictionsPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._degree_var = ctk.StringVar()
        self._years_var = ctk.StringVar(value="4")
        self._model_var = ctk.StringVar(value="linear")
        self._report_host = None
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        self.title("Career Predictions", self).pack(anchor="w", pady=(0, 4))
        self.subtitle(
            "Select a degree and prediction period. Predictions use trained "
            "Linear Regression and Random Forest models — estimates, not guarantees.",
            self).pack(anchor="w", pady=(0, 12))

        # Controls card
        ctrl = self.card()
        ctrl.pack(fill="x", pady=(0, 12))

        degrees = [d["name"] for d in prediction_service.list_degrees()]
        if degrees:
            self._degree_var.set(degrees[0])

        row = ctk.CTkFrame(ctrl, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=14)

        ctk.CTkLabel(row, text="Degree:", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 8))
        self.degree_menu = ctk.CTkOptionMenu(
            row, variable=self._degree_var, values=degrees,
            width=320, height=36, font=("Segoe UI", 12))
        self.degree_menu.pack(side="left", padx=(0, 20))

        ctk.CTkLabel(row, text="Predict for:", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 8))
        years_menu = ctk.CTkOptionMenu(
            row, variable=self._years_var,
            values=[str(y) for y in range(1, 11)],
            width=90, height=36)
        years_menu.pack(side="left", padx=(0, 20))
        ctk.CTkLabel(row, text="years", font=("Segoe UI", 12),
                     text_color=COLORS["muted"]).pack(side="left", padx=(0, 20))

        ctk.CTkLabel(row, text="Model:", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 8))
        model_menu = ctk.CTkOptionMenu(
            row, variable=self._model_var,
            values=["random_forest", "linear"], width=140, height=36)
        model_menu.pack(side="left", padx=(0, 20))

        ctk.CTkButton(row, text="Predict Future", height=38, width=140,
                      corner_radius=10, fg_color=COLORS["accent"],
                      hover_color=COLORS["primary"],
                      font=("Segoe UI", 13, "bold"),
                      command=self._run_prediction).pack(side="left")

        # Report host
        self._report_host = ctk.CTkFrame(self, fg_color="transparent")
        self._report_host.pack(fill="both", expand=True)

    def _run_prediction(self):
        for w in self._report_host.winfo_children():
            w.destroy()
        try:
            years = int(self._years_var.get())
            report = prediction_service.predict_career(
                self._degree_var.get(), years, self._model_var.get())
        except Exception as e:
            self.error_box(e)
            return
        self._render_report(report)

    def _render_report(self, r):
        host = self._report_host

        # Headline card
        head = self.card(host)
        head.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(head,
                     text=f"{r['degree']} — {r['current_year']} → {r['target_year']}",
                     font=("Segoe UI", 18, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 2))
        ctk.CTkLabel(head,
                     text=f"Engine: {r.get('engine', r['model_type'])}  |  Job demand level: {r['job_demand_level']}",
                     font=("Segoe UI", 12), text_color=COLORS["accent"]).pack(anchor="w", padx=18, pady=(0, 10))

        # KPI row
        kpis = [
            ("Predicted Salary", format_pkr_short(r["predicted_salary_pkr"]), "/month"),
            ("Salary Growth", f"{r['salary_growth_pct']}%" if r["salary_growth_pct"] is not None else "—", "over period"),
            ("Employment Growth", f"{r['employment_growth_pct']}%" if r['employment_growth_pct'] is not None else "—", "index change"),
            ("Demand Level", r["job_demand_level"], "out of Very High"),
        ]
        krow = ctk.CTkFrame(head, fg_color="transparent")
        krow.pack(fill="x", padx=12, pady=(0, 12))
        for label, value, sub in kpis:
            cell = ctk.CTkFrame(krow, fg_color=COLORS["bg"], corner_radius=10)
            cell.pack(side="left", fill="both", expand=True, padx=4)
            ctk.CTkLabel(cell, text=value, font=("Segoe UI", 18, "bold"),
                         text_color=COLORS["primary"]).pack(pady=(8, 0))
            ctk.CTkLabel(cell, text=label, font=("Segoe UI", 10, "bold"),
                         text_color=COLORS["muted"]).pack()
            ctk.CTkLabel(cell, text=sub, font=("Segoe UI", 9),
                         text_color=COLORS["muted"]).pack(pady=(0, 8))

        # Body columns
        body = ctk.CTkFrame(host, fg_color="transparent")
        body.pack(fill="x")
        left = ctk.CTkFrame(body, fg_color="transparent")
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right = ctk.CTkFrame(body, fg_color="transparent")
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))

        def bullet_card(parent, title, items, limit=None):
            card = self.card(parent)
            card.pack(fill="x", pady=6)
            ctk.CTkLabel(card, text=title, font=("Segoe UI", 13, "bold"),
                         text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
            for it in (items[:limit] if limit else items):
                ctk.CTkLabel(card, text=f"• {it}", font=("Segoe UI", 12),
                             text_color=COLORS["text"], wraplength=480,
                             justify="left").pack(anchor="w", padx=18, pady=1)
            ctk.CTkLabel(card, text="", height=8).pack()
            return card

        bullet_card(left, "Career Opportunities", r["career_opportunities"])
        bullet_card(left, "Required Future Skills", r["future_skills"])
        bullet_card(left, "Relevant Industries", r["industries"])
        bullet_card(right, "Potential Career Challenges", r["challenges"])
        bullet_card(right, "Recommended Certifications", r["certifications"])

        # Salary projection chart
        ch = self.card(host)
        ch.pack(fill="x", pady=8)
        ctk.CTkLabel(ch, text="Salary Projection (Estimated, PKR/month)",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 2))
        hist = r["salary_history"]
        proj = prediction_service.salary_projection(r["degree"], r["period_years"])
        if hist:
            fig = charts.salary_projection_chart(
                [h["year"] for h in hist], [h["avg_monthly_salary"] for h in hist],
                proj, f"{r['degree']} — Historical & Projected")
            charts.embed_figure(ch, fig)

        # Model metrics
        met = self.card(host)
        met.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(met, text="Model Evaluation (training fit)",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
        sm, em = r["salary_metrics"], r["employment_metrics"]
        txt = ""
        if sm:
            txt += (f"Salary ({r.get('engine', r['model_type'])}): MAE={sm['mae']:,.0f} PKR, "
                    f"RMSE={sm['rmse']:,.0f} PKR, R²={sm['r2']:.3f}    ")
        if em:
            txt += (f"Employment ({r.get('engine', r['model_type'])}): MAE={em['mae']:.2f}, "
                    f"RMSE={em['rmse']:.2f}, R²={em['r2']:.3f}")
        alt = ""
        if r.get("alt_salary_prediction"):
            alt = (f"   Alternative ({r['alt_model_type']}): salary "
                   f"{format_pkr_short(r['alt_salary_prediction'])}/mo, "
                   f"employment index {r.get('alt_employment_prediction')}")
        ctk.CTkLabel(met, text=txt + alt, font=("Segoe UI", 10),
                     text_color=COLORS["muted"], wraplength=1100,
                     justify="left").pack(anchor="w", padx=14, pady=(0, 6))
        ctk.CTkLabel(met, text=r["data_note"], font=("Segoe UI", 10, "italic"),
                     text_color=COLORS["warning"], wraplength=1100,
                     justify="left").pack(anchor="w", padx=14, pady=(0, 12))
