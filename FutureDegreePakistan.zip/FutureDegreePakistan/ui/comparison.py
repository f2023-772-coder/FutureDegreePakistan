"""Compare Degrees page: side-by-side comparison of 2-3 degrees."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS, format_pkr_short
import prediction_service
import charts

FIELDS = [
    ("current_salary", "Avg Monthly Salary (PKR)", format_pkr_short),
    ("projected_salary_5y", "5-Year Projected Salary", format_pkr_short),
    ("salary_growth_5y_pct", "Salary Growth 5Y (%)", lambda v: f"{v}%"),
    ("employment_growth_pct", "Employment Growth 5Y (%)", lambda v: f"{v}%"),
    ("demand_index", "Job Demand Index (1-10)", lambda v: f"{v}/10"),
    ("employment_index_now", "Employment Index (now)", lambda v: f"{v}"),
    ("employment_index_5y", "Employment Index (5Y)", lambda v: f"{v}"),
    ("job_positions_total", "Total Job Positions", lambda v: f"{v:,}"),
    ("top_careers", "Top Careers", str),
    ("top_industries", "Top Industries", str),
    ("key_skills", "Key Skills", str),
]


class ComparisonPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._vars = [ctk.StringVar(), ctk.StringVar(), ctk.StringVar()]
        self._result_host = None
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        self.title("Compare Degrees", self).pack(anchor="w", pady=(0, 4))
        self.subtitle("Select two or three degrees to compare career prospects.",
                      self).pack(anchor="w", pady=(0, 12))

        degrees = [d["name"] for d in prediction_service.list_degrees()]
        ctrl = self.card()
        ctrl.pack(fill="x", pady=(0, 12))
        for i, var in enumerate(self._vars):
            if degrees:
                # Pre-fill sensible distinct defaults.
                var.set(degrees[min(i * 5, len(degrees) - 1)])
            ctk.CTkLabel(ctrl, text=f"Degree {chr(65+i)}:",
                         font=("Segoe UI", 12, "bold"),
                         text_color=COLORS["text"]).grid(row=0, column=i, padx=14, pady=14)
            ctk.CTkOptionMenu(ctrl, variable=var, values=degrees,
                              width=280, height=36).grid(row=1, column=i, padx=14, pady=(0, 14))
        ctk.CTkButton(ctrl, text="Compare", height=38, width=140,
                      corner_radius=10, fg_color=COLORS["accent"],
                      hover_color=COLORS["primary"],
                      command=self._compare).grid(row=0, column=3, rowspan=2,
                                                  padx=20, pady=10)

        self._result_host = ctk.CTkFrame(self, fg_color="transparent")
        self._result_host.pack(fill="both", expand=True)

    def _compare(self):
        for w in self._result_host.winfo_children():
            w.destroy()
        names = [v.get() for v in self._vars if v.get()]
        # de-duplicate preserving order
        names = list(dict.fromkeys(names))
        if len(names) < 2:
            ctk.CTkLabel(self._result_host,
                         text="Please select at least two different degrees.",
                         text_color=COLORS["warning"]).pack(pady=20)
            return
        try:
            rows = prediction_service.compare_degrees(names[:3])
        except Exception as e:
            self.error_box(e)
            return
        if not rows:
            return
        self._render_table(rows)
        self._render_chart(rows)

    def _render_table(self, rows):
        card = self.card(self._result_host)
        card.pack(fill="x", pady=(0, 10))
        n = len(rows)
        # Let degree columns share the available width evenly.
        card.grid_columnconfigure(0, weight=0, minsize=160)
        for ci in range(1, n + 1):
            card.grid_columnconfigure(ci, weight=1, uniform="deg")
        # Header
        ctk.CTkLabel(card, text="Metric", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["muted"], anchor="w").grid(
            row=0, column=0, padx=14, pady=(12, 6), sticky="w")
        for i, r in enumerate(rows):
            ctk.CTkLabel(card, text=r["name"], font=("Segoe UI", 12, "bold"),
                         text_color=COLORS["primary"], anchor="w",
                         wraplength=280).grid(row=0, column=i + 1,
                                              padx=14, pady=(12, 6), sticky="w")
        for ri, (key, label, fmt) in enumerate(FIELDS, start=1):
            ctk.CTkLabel(card, text=label, font=("Segoe UI", 11),
                         text_color=COLORS["muted"], anchor="w").grid(
                row=ri, column=0, padx=14, pady=4, sticky="w")
            for ci, r in enumerate(rows):
                ctk.CTkLabel(card, text=fmt(r.get(key)), font=("Segoe UI", 11),
                             text_color=COLORS["text"], anchor="w",
                             wraplength=280, justify="left").grid(
                    row=ri, column=ci + 1, padx=14, pady=4, sticky="w")
        ctk.CTkLabel(card, text="", height=10).grid(row=len(FIELDS) + 1, column=0,
                                                  columnspan=n + 1)

    def _render_chart(self, rows):
        card = self.card(self._result_host)
        card.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(card, text="Salary Comparison (PKR/month)",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 2))
        datasets = {
            "Current": [r["current_salary"] / 1000 for r in rows],
            "5-Year Projected": [r["projected_salary_5y"] / 1000 for r in rows],
        }
        fig = charts.multi_bar_chart([r["name"].replace("BS ", "") for r in rows],
                                     datasets, "Current vs 5-Year Salary (PKR '000)",
                                     ylabel="PKR '000 / month")
        charts.embed_figure(card, fig)
