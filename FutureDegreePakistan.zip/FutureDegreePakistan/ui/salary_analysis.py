"""Salary Analysis page: starting/average/experienced salaries + growth."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS, format_pkr_short
import prediction_service
import charts


class SalaryPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        self.title("Salary Analysis", self).pack(anchor="w", pady=(0, 4))
        self.subtitle("Estimated salaries in Pakistani Rupees (PKR). "
                      "Based on simulated historical data — illustrative estimates only.",
                      self).pack(anchor="w", pady=(0, 12))

        rows = sorted(prediction_service.salary_analysis(),
                      key=lambda r: r["current_salary"], reverse=True)

        # Top-15 salary bar chart
        top = rows[:15]
        c = self.card()
        c.pack(fill="x", pady=(0, 10))
        fig = charts.bar_chart(
            [r["name"].replace("BS ", "") for r in top],
            [r["current_salary"] / 1000 for r in top],
            "Average Monthly Salary by Degree — Top 15 (PKR '000)",
            horizontal=True)
        charts.embed_figure(c, fig)

        # 10-year growth chart for selected degree
        c2 = self.card()
        c2.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(c2, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=(10, 4))
        ctk.CTkLabel(row, text="Salary growth over 1-10 years for:",
                     font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 10))
        names = [r["name"] for r in rows]
        var = ctk.StringVar(value=names[0] if names else "")
        menu = ctk.CTkOptionMenu(row, variable=var, values=names,
                                 width=320, height=34)
        menu.pack(side="left")
        chart_host = ctk.CTkFrame(c2, fg_color="transparent")
        chart_host.pack(fill="x", padx=10, pady=(0, 10))

        def draw():
            for w in chart_host.winfo_children():
                w.destroy()
            hist = prediction_service.degree_details(var.get())["salary_history"]
            proj = prediction_service.salary_projection(var.get(), 10)
            fig = charts.salary_projection_chart(
                [h["year"] for h in hist], [h["avg_monthly_salary"] for h in hist],
                proj, f"{var.get()} — 10-Year Salary Projection")
            charts.embed_figure(chart_host, fig)

        menu.configure(command=lambda v: draw())
        self.after(50, draw)

        # Full table
        card = self.card()
        card.pack(fill="x", pady=(0, 10))
        for ci in range(6):
            card.grid_columnconfigure(ci, weight=1, uniform="sal")
        headers = ["Degree", "Category", "Starting Salary", "Current Avg",
                   "10-Year Salary", "Growth %"]
        for ci, h in enumerate(headers):
            ctk.CTkLabel(card, text=h, font=("Segoe UI", 11, "bold"),
                         text_color=COLORS["muted"], anchor="w").grid(
                row=0, column=ci, padx=12, pady=(10, 6), sticky="w")
        for ri, r in enumerate(rows, start=1):
            vals = [r["name"], r["category"],
                    format_pkr_short(r["starting_salary"]),
                    format_pkr_short(r["current_salary"]),
                    format_pkr_short(r["salary_10y"]),
                    f"{r['growth_pct']}%"]
            for ci, v in enumerate(vals):
                ctk.CTkLabel(card, text=str(v), font=("Segoe UI", 11),
                             text_color=COLORS["text"], anchor="w",
                             wraplength=220).grid(row=ri, column=ci,
                                                  padx=12, pady=3, sticky="w")
        ctk.CTkLabel(card, text="", height=10).grid(row=len(rows) + 1, column=0)

        note = self.card()
        note.pack(fill="x")
        ctk.CTkLabel(note,
                     text="Data source: simulated historical salary series stored in the "
                          "local SQLite database (data_source='estimated'). Salaries are "
                          "monthly averages in PKR and are illustrative, not guaranteed.",
                     font=("Segoe UI", 10), text_color=COLORS["muted"],
                     wraplength=1100, justify="left").pack(anchor="w", padx=16, pady=12)
