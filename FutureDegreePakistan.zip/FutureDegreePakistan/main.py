"""FutureDegree Pakistan — Offline Big Data Career Prediction System.

Run with:  python main.py
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
for sub in ["database", "models", "services", "utils", "ui"]:
    p = os.path.join(BASE_DIR, sub)
    if p not in sys.path:
        sys.path.insert(0, p)

import customtkinter as ctk

import helpers  # noqa: F401  (sets up sys.path for all submodules)
from helpers import COLORS
from ui.dashboard import DashboardPage
from ui.degrees import DegreesPage
from ui.predictions import PredictionsPage
from ui.comparison import ComparisonPage
from ui.salary_analysis import SalaryPage
from ui.job_trends import TrendsPage
from ui.skills import SkillsPage
from ui.about import AboutPage
from ui.settings import SettingsPage

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

APP_TITLE = "FutureDegree Pakistan"

PAGES = {
    "Dashboard": DashboardPage,
    "Explore Degrees": DegreesPage,
    "Career Predictions": PredictionsPage,
    "Compare Degrees": ComparisonPage,
    "Salary Analysis": SalaryPage,
    "Job Market Trends": TrendsPage,
    "Skills Recommendations": SkillsPage,
    "About Project": AboutPage,
    "Settings": SettingsPage,
}


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1360x860")
        self.minsize(1100, 700)
        # Start maximized (normal window, title bar + taskbar stay visible);
        # user can still minimize/restore/close via standard controls.
        self._maximize()
        self.configure(fg_color=COLORS["bg"])

        self._build_sidebar()
        self._build_content()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.show_page("Dashboard")

    def _maximize(self):
        """Maximize the window (normal maximized state, NOT fullscreen).

        Keeps the Windows title bar and taskbar visible; minimize,
        maximize/restore and close controls all keep working.
        """
        try:
            # Windows / X11 Tk: 'zoomed' is the maximized state.
            self.state("zoomed")
            return
        except Exception:
            pass
        try:
            # macOS Tk fallback.
            self.attributes("-zoomed", True)
        except Exception:
            pass

    def _on_close(self):
        try:
            import spark_service
            spark_service.stop_spark()
        except Exception:
            pass
        self.destroy()

    # ---------------- Sidebar ----------------
    def _build_sidebar(self):
        self.sidebar = ctk.CTkFrame(self, width=230, corner_radius=0,
                                    fg_color=COLORS["primary_dark"])
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        ctk.CTkLabel(self.sidebar, text="FutureDegree", font=("Segoe UI", 20, "bold"),
                     text_color="white").pack(pady=(24, 0))
        ctk.CTkLabel(self.sidebar, text="Pakistan", font=("Segoe UI", 14),
                     text_color=COLORS["accent"]).pack(pady=(0, 20))

        self.nav_buttons = {}
        for name in PAGES:
            btn = ctk.CTkButton(
                self.sidebar, text=name, anchor="w",
                font=("Segoe UI", 13), height=38, corner_radius=10,
                fg_color="transparent", text_color="#CBD5E1",
                hover_color=COLORS["primary"],
                command=lambda n=name: self.show_page(n))
            btn.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[name] = btn

        ctk.CTkLabel(self.sidebar, text="Offline • SQLite • ML",
                     font=("Segoe UI", 10), text_color="#64748B").pack(side="bottom", pady=14)

    # ---------------- Content ----------------
    def _build_content(self):
        self.content = ctk.CTkFrame(self, fg_color=COLORS["bg"], corner_radius=0)
        self.content.pack(side="right", fill="both", expand=True)
        self.current_page = None

    def show_page(self, name):
        if self.current_page:
            self.current_page.destroy()
        # highlight active nav button
        for n, btn in self.nav_buttons.items():
            if n == name:
                btn.configure(fg_color=COLORS["accent"], text_color="white")
            else:
                btn.configure(fg_color="transparent", text_color="#CBD5E1")
        page_cls = PAGES[name]
        self.current_page = page_cls(self.content, app=self)
        self.current_page.pack(fill="both", expand=True, padx=18, pady=16)


if __name__ == "__main__":
    app = App()
    app.mainloop()
