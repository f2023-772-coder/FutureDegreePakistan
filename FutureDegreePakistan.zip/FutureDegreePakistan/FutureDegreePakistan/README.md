# FutureDegree Pakistan

An **Offline Big Data-Based Educational and Career Prediction System** for Pakistani students.
Helps choose university degrees based on career opportunities, employment demand, expected
salaries, industry trends and future growth predictions.

## Features

- **Dashboard** — KPIs, degree distribution, salary & demand charts.
- **Explore Degrees** — all 30 degree programs with searchable cards and full profiles.
- **Career Predictions** — 1–10 year forecasts using Linear Regression and Random Forest
  (trained with scikit-learn, saved with Joblib).
- **Compare Degrees** — side-by-side comparison of 2–3 degrees.
- **Salary Analysis** — starting / average / projected salaries in PKR with growth charts.
- **Job Market Trends** — historical and predicted employment trends by category.
- **Skills Recommendations** — technical, soft, industry skills and certifications.
- **SQLite database** — normalized schema (degrees, subjects, skills, careers, industries,
  certifications, challenges, salary_history, employment_history, predictions).
- **Dataset pipeline** — CSV datasets in `datasets/` that can be extended with real data.

## IMPORTANT — Data Notice

The historical salary/employment series bundled with this project are **simulated
illustrative estimates** (`data_source='estimated'`). They are **not** official Pakistani
employment statistics. All predictions are estimates for guidance only and are not
guaranteed. To use real data, append verified rows to the CSVs in `datasets/` and
retrain the models (Settings → Retrain ML models).

## Tech Stack

Python 3.11+, CustomTkinter, SQLite, Pandas, NumPy, Scikit-learn, Matplotlib, Joblib.
Runs **fully offline** after `pip install -r requirements.txt`.

## Setup

```bash
pip install -r requirements.txt
python main.py
```

On first run the app automatically initializes the SQLite database, seeds all 30
degrees, and trains the ML models. You can also run these steps manually:

```bash
python database/db_setup.py
python database/seed_data.py
python datasets/generate_datasets.py
python models/train_models.py
```

## Project Structure

```
FutureDegreePakistan/
├── main.py                  # Application entry point
├── requirements.txt
├── database/                # SQLite connection, schema, seed data
├── models/                  # ML models + training script + saved_models/
├── datasets/                # CSV datasets + generator
├── services/                # Prediction, data processing, recommendations
├── ui/                      # CustomTkinter pages
└── utils/                   # Charts and helpers
```
