"""Database connection utilities for FutureDegree Pakistan."""
import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_DIR = os.path.join(BASE_DIR, "database")
DB_PATH = os.path.join(DB_DIR, "futuredegree.db")


def get_connection(db_path=None):
    """Return a sqlite3 connection with row factory enabled."""
    path = db_path or DB_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def query(sql, params=(), db_path=None):
    """Run a SELECT and return a list of dicts."""
    with get_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        return [dict(row) for row in cur.fetchall()]


def execute(sql, params=(), db_path=None):
    """Run a write statement and return lastrowid."""
    with get_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid


def execute_many(sql, rows, db_path=None):
    """Run many write statements in one transaction."""
    with get_connection(db_path) as conn:
        conn.executemany(sql, rows)
        conn.commit()
