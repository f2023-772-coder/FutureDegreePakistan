"""Seed data for all 30 degree programs.

Historical salary/employment series are SIMULATED illustrative estimates
(derived from each degree's base salary and growth assumptions) and are
labelled data_source='estimated' in the database. They are NOT official
Pakistani employment statistics.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from db_connection import execute, execute_many, query, get_connection
from db_setup import init_database

# Base monthly salary (PKR, mid-career estimate) and annual growth fraction
# used to build the illustrative historical series 2018-2025.
DEGREES = [
    # ---- Technology ----
    dict(name="BS Computer Science", category="Technology", duration="4 years",
         base_salary=150000, growth=0.10, demand=9.0,
         description="BS Computer Science covers algorithms, data structures, software engineering, databases, operating systems and AI fundamentals, preparing graduates for software development, systems and research roles.",
         subjects=["Data Structures & Algorithms", "Database Systems", "Operating Systems", "Software Engineering", "Artificial Intelligence", "Computer Networks"],
         skills=[("Programming (Python/C++/Java)", "technical", 5), ("Data Structures & Algorithms", "technical", 5),
                 ("SQL & Database Design", "technical", 4), ("Version Control (Git)", "technical", 4),
                 ("Problem Solving", "soft", 5), ("Team Collaboration", "soft", 4)],
         careers=[("Software Engineer", 12000), ("Backend Developer", 9000), ("Data Analyst", 6000), ("DevOps Engineer", 5000)],
         industries=["Software Houses", "IT Services", "Banking & Finance", "Telecom"],
         certs=["AWS Certified Solutions Architect", "Oracle Java Certification", "Microsoft Azure Fundamentals"],
         challenges=["Intense competition for entry-level roles", "Rapidly changing technology stack", "Many fresh graduates lack practical experience"]),
    dict(name="BS Software Engineering", category="Technology", duration="4 years",
         base_salary=145000, growth=0.09, demand=8.5,
         description="BS Software Engineering focuses on designing, building and maintaining large software systems using engineering principles, testing, project management and agile methodologies.",
         subjects=["Software Requirements Engineering", "Software Testing", "Project Management", "Web Development", "Software Architecture", "UML & Modeling"],
         skills=[("Full-Stack Web Development", "technical", 5), ("Software Testing & QA", "technical", 4), ("Agile/Scrum Methodologies", "technical", 4),
                 ("System Design", "technical", 4), ("Communication", "soft", 4), ("Analytical Thinking", "soft", 5)],
         careers=[("Software Engineer", 11000), ("QA Engineer", 5000), ("Systems Analyst", 4000), ("Project Manager (IT)", 3500)],
         industries=["Software Houses", "E-commerce", "Banking & Finance", "Government IT"],
         certs=["Certified Scrum Master (CSM)", "ISTQB Foundation", "AWS Cloud Practitioner"],
         challenges=["Blurring line between CS and SE roles", "Need for strong communication skills", "Contract/freelance market volatility"]),
    dict(name="BS Artificial Intelligence", category="Technology", duration="4 years",
         base_salary=180000, growth=0.15, demand=9.5,
         description="BS Artificial Intelligence covers machine learning, deep learning, neural networks, natural language processing, computer vision and AI ethics — among the fastest-growing fields globally and in Pakistan.",
         subjects=["Machine Learning", "Deep Learning", "Natural Language Processing", "Computer Vision", "Data Mining", "AI Ethics"],
         skills=[("Python & ML Frameworks (TensorFlow/PyTorch)", "technical", 5), ("Statistics & Linear Algebra", "technical", 5), ("Data Wrangling", "technical", 4),
                 ("Model Evaluation & Deployment", "technical", 4), ("Research Skills", "soft", 4), ("Ethical Reasoning", "soft", 4)],
         careers=[("Machine Learning Engineer", 6000), ("AI Researcher", 3000), ("Data Scientist", 7000), ("Computer Vision Engineer", 3500)],
         industries=["Tech Startups", "Banking & Finance", "Healthcare AI", "E-commerce & Logistics"],
         certs=["DeepLearning.AI Specializations", "TensorFlow Developer Certificate", "Google Data Analytics"],
         challenges=["High mathematical prerequisites", "Computing resource costs", "Few senior roles — steep learning curve"]),
    dict(name="BS Data Science", category="Technology", duration="4 years",
         base_salary=160000, growth=0.12, demand=9.0,
         description="BS Data Science combines statistics, programming, machine learning and domain knowledge to extract insights and build predictive models from large datasets.",
         subjects=["Statistics & Probability", "Machine Learning", "Data Visualization", "Big Data Technologies", "Database Management", "Business Analytics"],
         skills=[("Python/R Programming", "technical", 5), ("Statistics & Probability", "technical", 5), ("SQL", "technical", 4),
                 ("Data Visualization (Tableau/PowerBI)", "technical", 4), ("Business Acumen", "soft", 4), ("Storytelling with Data", "soft", 4)],
         careers=[("Data Scientist", 7000), ("Data Analyst", 8000), ("Business Intelligence Analyst", 5000), ("ML Engineer", 4500)],
         industries=["Banking & Finance", "Telecom", "E-commerce", "Government & NGOs"],
         certs=["Google Data Analytics", "Microsoft Power BI Data Analyst", "AWS Data Analytics"],
         challenges=["Competition with self-taught analysts", "Need for domain knowledge", "Tooling evolves quickly"]),
    dict(name="BS Cyber Security", category="Technology", duration="4 years",
         base_salary=170000, growth=0.13, demand=9.2,
         description="BS Cyber Security trains students in network security, cryptography, ethical hacking, digital forensics, risk management and secure software development.",
         subjects=["Network Security", "Cryptography", "Ethical Hacking", "Digital Forensics", "Risk Management", "Secure Software Development"],
         skills=[("Network Security & Firewall Configuration", "technical", 5), ("Linux Administration", "technical", 4), ("Python for Security", "technical", 4),
                 ("Penetration Testing", "technical", 4), ("Attention to Detail", "soft", 5), ("Ethical Judgment", "soft", 5)],
         careers=[("Security Analyst", 5000), ("Penetration Tester", 4000), ("SOC Analyst", 4500), ("Security Consultant", 3000)],
         industries=["Banking & Finance", "Government", "Telecom", "IT Services"],
         certs=["CEH (Certified Ethical Hacker)", "CompTIA Security+", "CISSP (later stage)"],
         challenges=["Requires constant upskilling", "High-stress incident response roles", "Smaller job market than software dev"]),
    dict(name="BS Information Technology", category="Technology", duration="4 years",
         base_salary=140000, growth=0.08, demand=8.0,
         description="BS Information Technology focuses on IT infrastructure, networks, systems administration, cloud computing and enterprise technology management.",
         subjects=["Computer Networks", "Systems Administration", "Cloud Computing", "IT Project Management", "Web Technologies", "Database Administration"],
         skills=[("Networking (TCP/IP, Cisco)", "technical", 5), ("Linux/Windows Server Admin", "technical", 4), ("Cloud Platforms (AWS/Azure)", "technical", 4),
                 ("Database Administration", "technical", 4), ("Customer Service Orientation", "soft", 4), ("Documentation Skills", "soft", 3)],
         careers=[("Systems Administrator", 6000), ("Network Engineer", 5000), ("IT Support Specialist", 4000), ("Cloud Engineer", 5000)],
         industries=["Banking & Finance", "Telecom", "Government", "Corporate IT"],
         certs=["CompTIA Network+", "CCNA", "AWS Solutions Architect Associate"],
         challenges=["Less glamour than pure software roles", "On-call support duties", "Vendor certification costs"]),

    # ---- Engineering ----
    dict(name="Electrical Engineering", category="Engineering", duration="4 years",
         base_salary=120000, growth=0.07, demand=7.5,
         description="Electrical Engineering covers power systems, electronics, control systems, signal processing and renewable energy — core to Pakistan's energy and manufacturing sectors.",
         subjects=["Circuit Analysis", "Power Systems", "Electronics", "Control Systems", "Signals & Systems", "Electrical Machines"],
         skills=[("Circuit Design & Analysis", "technical", 5), ("PLC & Industrial Automation", "technical", 4), ("MATLAB/Simulink", "technical", 4),
                 ("Power System Analysis", "technical", 4), ("Field Problem Solving", "soft", 4), ("Safety Awareness", "soft", 5)],
         careers=[("Power Engineer", 5000), ("Electronics Engineer", 4500), ("Automation Engineer", 4500), ("Site Engineer (Power)", 4000)],
         industries=["Energy & Power", "Manufacturing", "Telecom", "Construction"],
         certs=["PEC License (after experience)", "Autodesk Certified", "Six Sigma Green Belt"],
         challenges=["Field work in remote locations", "Industry exposure needed for growth", "Limited postings in some cities"]),
    dict(name="Mechanical Engineering", category="Engineering", duration="4 years",
         base_salary=110000, growth=0.06, demand=7.0,
         description="Mechanical Engineering covers thermodynamics, fluid mechanics, manufacturing processes, machine design and robotics — serving automotive, energy and industrial sectors.",
         subjects=["Thermodynamics", "Fluid Mechanics", "Machine Design", "Manufacturing Processes", "Engineering Mechanics", "Mechatronics"],
         skills=[("CAD (AutoCAD/SolidWorks)", "technical", 5), ("Thermodynamics & Heat Transfer", "technical", 4), ("Manufacturing Processes", "technical", 4),
                 ("FEA/Simulation Tools", "technical", 3), ("Practical Problem Solving", "soft", 4), ("Technical Drawing", "soft", 4)],
         careers=[("Design Engineer", 5000), ("Manufacturing Engineer", 4500), ("Maintenance Engineer", 4000), ("Project Engineer", 4500)],
         industries=["Manufacturing", "Automotive", "Energy", "Construction"],
         certs=["SolidWorks CSWA", "Autodesk Certified Professional", "Six Sigma"],
         challenges=["Physical site requirements", "Slow promotion in some firms", "Seasonal hiring patterns"]),
    dict(name="Civil Engineering", category="Engineering", duration="4 years",
         base_salary=100000, growth=0.05, demand=6.5,
         description="Civil Engineering covers structural design, construction management, geotechnical engineering, transportation and water resources for Pakistan's infrastructure development.",
         subjects=["Structural Analysis", "Geotechnical Engineering", "Construction Management", "Transportation Engineering", "Hydraulics", "Surveying"],
         skills=[("Structural Design (ETABS/SAP2000)", "technical", 5), ("AutoCAD/Civil 3D", "technical", 4), ("Construction Management", "technical", 4),
                 ("Project Estimation & Costing", "technical", 4), ("Site Supervision", "soft", 4), ("Negotiation", "soft", 3)],
         careers=[("Site Engineer", 4000), ("Design Engineer", 5000), ("Project Manager (Construction)", 6000), ("Quantity Surveyor", 4500)],
         industries=["Construction", "Real Estate", "Government Infrastructure", "Consulting"],
         certs=["PEC License", "Project Management Professional (PMP)", "Chartered Engineer status"],
         challenges=["Outdoor/site work conditions", "Payment delays in private sector", "Seasonal demand fluctuations"]),
    dict(name="Chemical Engineering", category="Engineering", duration="4 years",
         base_salary=115000, growth=0.06, demand=6.8,
         description="Chemical Engineering applies chemistry, physics and engineering to industrial processes in pharmaceuticals, textiles, food, energy and petrochemicals.",
         subjects=["Chemical Thermodynamics", "Fluid Mechanics", "Process Design", "Reaction Engineering", "Mass Transfer", "Plant Design"],
         skills=[("Process Simulation (Aspen Plus)", "technical", 5), ("Chemical Process Design", "technical", 4), ("Safety & Hazard Analysis", "technical", 4),
                 ("Plant Operations", "technical", 4), ("Safety Compliance", "soft", 5), ("Team Coordination", "soft", 3)],
         careers=[("Process Engineer", 5500), ("Production Engineer", 4500), ("Plant Engineer", 5000), ("Quality Assurance Engineer", 4500)],
         industries=["Pharmaceuticals", "Textiles", "Food & Beverage", "Oil & Gas"],
         certs=["IChemE Membership", "Process Safety Management", "Six Sigma"],
         challenges=["Plant/site postings limited to industrial zones", "Safety-critical role pressure", "Shift work requirements"]),
    dict(name="Computer Engineering", category="Engineering", duration="4 years",
         base_salary=150000, growth=0.11, demand=8.8,
         description="Computer Engineering bridges hardware and software — embedded systems, VLSI, robotics, IoT, computer architecture and firmware development.",
         subjects=["Digital Logic Design", "Microprocessors", "Embedded Systems", "VLSI Design", "Computer Architecture", "Robotics"],
         skills=[("Embedded C/C++", "technical", 5), ("Microcontroller Programming", "technical", 5), ("PCB Design", "technical", 4),
                 ("IoT Protocols", "technical", 4), ("Debugging Hardware Issues", "soft", 4), ("Datasheet Reading", "soft", 4)],
         careers=[("Embedded Systems Engineer", 6000), ("Firmware Engineer", 5500), ("IoT Developer", 5000), ("Hardware Engineer", 5000)],
         industries=["Electronics Manufacturing", "Automotive", "Telecom Equipment", "IoT Startups"],
         certs=["Embedded Systems Certificate", "FPGA Design", "IoT Specialization"],
         challenges=["Requires lab hardware access", "Niche compared to CS roles", "Hardware debugging skills take time"]),

    # ---- Medical & Health ----
    dict(name="MBBS", category="Medical & Health", duration="5 years",
         base_salary=180000, growth=0.09, demand=9.0,
         description="MBBS (Bachelor of Medicine, Bachelor of Surgery) is the professional medical degree leading to practice as a physician, with pathways into specialization, research and public health.",
         subjects=["Anatomy", "Physiology", "Pharmacology", "Pathology", "Medicine & Surgery", "Community Medicine"],
         skills=[("Clinical Diagnosis", "technical", 5), ("Patient Communication", "soft", 5), ("Surgical & Medical Procedures", "technical", 5),
                 ("Medical Research Methods", "technical", 3), ("Empathy", "soft", 5), ("Stress Management", "soft", 4)],
         careers=[("General Physician", 8000), ("Medical Officer (Hospital)", 7000), ("Specialist (post-MCPS)", 15000), ("Public Health Officer", 6000)],
         industries=["Hospitals & Clinics", "Public Health Sector", "Pharmaceutical Industry", "Medical Education"],
         certs=["PMDC Registration", "FCPS/MCPS (postgraduate)", "Advanced Cardiac Life Support (ACLS)"],
         challenges=["Long and expensive training path", "High-stress work environment", "Specialization requires further years of study"]),
    dict(name="BDS", category="Medical & Health", duration="4 years",
         base_salary=120000, growth=0.08, demand=7.5,
         description="BDS (Bachelor of Dental Surgery) prepares students for dental practice, oral surgery, orthodontics and community dentistry.",
         subjects=["Oral Anatomy", "Dental Materials", "Oral Pathology", "Orthodontics", "Oral Surgery", "Community Dentistry"],
         skills=[("Dental Procedures", "technical", 5), ("Manual Dexterity", "soft", 5), ("Patient Management", "soft", 4),
                 ("Dental Imaging", "technical", 4), ("Hygiene Protocols", "soft", 5), ("Business Acumen (private practice)", "soft", 4)],
         careers=[("Dental Surgeon", 8000), ("Orthodontist (post-MDS)", 12000), ("Dental Officer", 6000), ("Dental Educator", 6000)],
         industries=["Dental Clinics", "Hospitals", "Private Practice", "Medical Colleges"],
         certs=["PMDC Registration", "MDS Specialization", "Infection Control Certification"],
         challenges=["High equipment costs for private practice", "Postgraduate specialization needed for top salaries", "Manual skill intensive"]),
    dict(name="Pharm-D", category="Medical & Health", duration="5 years",
         base_salary=100000, growth=0.07, demand=7.8,
         description="Pharm-D is the professional pharmacy doctorate covering drug formulation, pharmacology, clinical pharmacy, hospital pharmacy and pharmaceutical industry roles.",
         subjects=["Pharmaceutical Chemistry", "Pharmacology", "Pharmaceutics", "Pharmacognosy", "Clinical Pharmacy", "Hospital Pharmacy"],
         skills=[("Drug Formulation", "technical", 5), ("Clinical Knowledge", "technical", 5), ("Quality Control", "technical", 4),
                 ("Patient Counseling", "soft", 4), ("Regulatory Compliance", "technical", 4), ("Attention to Detail", "soft", 5)],
         careers=[("Hospital Pharmacist", 6000), ("Community Pharmacist", 5000), ("Production Pharmacist", 7000), ("Clinical Research Associate", 8000)],
         industries=["Pharmaceutical Companies", "Hospitals", "Retail Pharmacies", "Regulatory Bodies"],
         certs=["PMDC/DRAP Registration", "Clinical Pharmacy Certification", "GMP Certification"],
         challenges=["Industry vs hospital career paths differ greatly", "Regulatory knowledge required", "Shift work in hospitals"]),
    dict(name="BS Nursing", category="Medical & Health", duration="4 years",
         base_salary=90000, growth=0.09, demand=9.0,
         description="BS Nursing prepares registered nurses for hospitals, clinics, community health, and specialized care units, with strong demand locally and abroad.",
         subjects=["Anatomy & Physiology", "Medical-Surgical Nursing", "Pediatric Nursing", "Community Health Nursing", "Mental Health Nursing", "Nursing Research"],
         skills=[("Patient Care & Clinical Skills", "technical", 5), ("Wound Care & Medication Administration", "technical", 5), ("Critical Thinking", "soft", 4),
                 ("Empathy & Compassion", "soft", 5), ("Communication", "soft", 4), ("Physical Stamina", "soft", 4)],
         careers=[("Registered Nurse", 6000), ("Charge Nurse", 8000), ("Community Health Nurse", 5000), ("Nurse Educator", 9000)],
         industries=["Hospitals", "Clinics", "Public Health Programs", "International Employment (Gulf/UK)"],
         certs=["PNC Registration", "BLS/ACLS Certification", "Specialty Certifications (ICU, OR)"],
         challenges=["Physically and emotionally demanding", "Shift/night duties", "Workplace safety risks"]),
    dict(name="DPT", category="Medical & Health", duration="4 years",
         base_salary=90000, growth=0.10, demand=8.2,
         description="Doctor of Physical Therapy (DPT) trains students to treat musculoskeletal, neurological and sports injuries through rehabilitation and physical therapy.",
         subjects=["Kinesiology", "Exercise Physiology", "Manual Therapy", "Neurology", "Orthopedics", "Electrotherapy"],
         skills=[("Manual Therapy Techniques", "technical", 5), ("Exercise Prescription", "technical", 5), ("Patient Assessment", "technical", 4),
                 ("Physical Stamina", "soft", 4), ("Motivational Communication", "soft", 4), ("Clinical Documentation", "soft", 3)],
         careers=[("Physical Therapist", 7000), ("Sports Physiotherapist", 9000), ("Rehabilitation Specialist", 7000), ("Clinic Owner", 12000)],
         industries=["Rehabilitation Centers", "Sports Teams", "Hospitals", "Private Clinics"],
         certs=["PMDC Registration", "Orthopedic Manual Therapy (OMT)", "Sports Physiotherapy Certifications"],
         challenges=["Building a private practice takes time", "Physical demands of treatment", "Awareness of profession still growing"]),
    dict(name="BS Medical Laboratory Technology", category="Medical & Health", duration="4 years",
         base_salary=80000, growth=0.07, demand=7.5,
         description="BS Medical Laboratory Technology trains technologists to perform diagnostic tests in pathology, microbiology, hematology and biochemistry labs.",
         subjects=["Clinical Pathology", "Microbiology", "Hematology", "Biochemistry", "Immunology", "Laboratory Management"],
         skills=[("Laboratory Techniques & Microscopy", "technical", 5), ("Quality Control in Labs", "technical", 4), ("Sample Handling", "technical", 4),
                 ("Accuracy & Precision", "soft", 5), ("Biosafety Protocols", "soft", 5), ("Report Writing", "soft", 3)],
         careers=[("Medical Lab Technologist", 6000), ("Pathology Technician", 5500), ("Lab Supervisor", 8000), ("Quality Control Officer", 7000)],
         industries=["Diagnostic Labs", "Hospitals", "Blood Banks", "Research Institutions"],
         certs=["PMDC Registration", "ASCP Certification (international)", "Biosafety Certification"],
         challenges=["Behind-the-scenes role limits visibility", "Biohazard exposure risk", "Career progression slower than clinical roles"]),

    # ---- Business & Finance ----
    dict(name="BBA", category="Business & Finance", duration="4 years",
         base_salary=90000, growth=0.07, demand=8.0,
         description="Bachelor of Business Administration provides broad business education covering marketing, finance, HR, operations and entrepreneurship.",
         subjects=["Principles of Management", "Financial Accounting", "Marketing", "Human Resource Management", "Business Economics", "Business Law"],
         skills=[("Business Analysis", "technical", 4), ("Microsoft Office & ERP", "technical", 4), ("Negotiation", "soft", 4),
                 ("Leadership", "soft", 5), ("Communication", "soft", 5), ("Networking", "soft", 4)],
         careers=[("Business Analyst", 6000), ("Marketing Executive", 5000), ("HR Executive", 5500), ("Operations Manager", 7000)],
         industries=["Corporate Sector", "Banking & Finance", "FMCG", "Startups"],
         certs=["CFA Level 1 (Finance track)", "PMP", "Digital Marketing Certifications"],
         challenges=["Generic degree — specialization needed", "Networking crucial for good roles", "Entry salaries modest compared to tech"]),
    dict(name="BS Accounting and Finance", category="Business & Finance", duration="4 years",
         base_salary=95000, growth=0.07, demand=7.8,
         description="BS Accounting and Finance covers financial reporting, auditing, taxation, investment analysis and corporate finance for accounting and finance careers.",
         subjects=["Financial Accounting", "Cost Accounting", "Auditing", "Corporate Finance", "Taxation", "Financial Analysis"],
         skills=[("Financial Modeling (Excel)", "technical", 5), ("IFRS/GAAP Standards", "technical", 5), ("Tax Planning", "technical", 4),
                 ("Attention to Detail", "soft", 5), ("Ethical Judgment", "soft", 5), ("Report Communication", "soft", 4)],
         careers=[("Accountant", 6000), ("Auditor", 7000), ("Financial Analyst", 8000), ("Tax Advisor", 7000)],
         industries=["Accounting Firms", "Banking & Finance", "Corporate Sector", "Government"],
         certs=["ACCA", "CPA (partial route)", "CMA"],
         challenges=["Chartered accountancy requires further exams", "Busy season workload", "Regulatory updates demand continuous learning"]),
    dict(name="BS Economics", category="Business & Finance", duration="4 years",
         base_salary=100000, growth=0.08, demand=7.5,
         description="BS Economics studies micro and macro economics, econometrics, development economics and policy analysis for roles in research, banking and public sector.",
         subjects=["Microeconomics", "Macroeconomics", "Econometrics", "Development Economics", "International Trade", "Public Finance"],
         skills=[("Economic Analysis", "technical", 5), ("Econometrics (Stata/R/Python)", "technical", 4), ("Data Interpretation", "technical", 4),
                 ("Critical Thinking", "soft", 5), ("Report Writing", "soft", 4), ("Policy Understanding", "soft", 4)],
         careers=[("Economic Analyst", 8000), ("Research Associate", 7000), ("Policy Analyst", 7000), ("Banking Sector Economist", 9000)],
         industries=["Banking & Finance", "Think Tanks", "Government Planning", "International Organizations"],
         certs=["Research Methodology Courses", "Stata/R Certifications", "Postgraduate Economics (MS/MPhil)"],
         challenges=["Often requires postgraduate degree for top roles", "Abstract subject matter", "Public sector hiring slow"]),
    dict(name="BS Banking and Finance", category="Business & Finance", duration="4 years",
         base_salary=95000, growth=0.08, demand=8.2,
         description="BS Banking and Finance focuses on banking operations, risk management, investment banking, Islamic finance and fintech for the financial sector.",
         subjects=["Banking Operations", "Risk Management", "Investment Analysis", "Islamic Finance", "Fintech", "Monetary Economics"],
         skills=[("Financial Analysis", "technical", 5), ("Risk Assessment", "technical", 4), ("Excel & Financial Tools", "technical", 4),
                 ("Regulatory Knowledge (SECP/State Bank)", "technical", 4), ("Client Relations", "soft", 4), ("Ethical Conduct", "soft", 5)],
         careers=[("Banking Officer", 6000), ("Credit Analyst", 8000), ("Relationship Manager", 9000), ("Risk Manager", 10000)],
         industries=["Commercial Banks", "Investment Banks", "Microfinance", "Fintech Startups"],
         certs=["CFA", "FRM (Financial Risk Manager)", "CIB (Chartered Institute of Bankers)"],
         challenges=["Regulatory compliance pressure", "Sales targets in branch roles", "Economic downturns affect hiring"]),
    dict(name="LLB", category="Business & Finance", duration="3 years",
         base_salary=100000, growth=0.08, demand=8.0,
         description="LLB (Bachelor of Laws) trains students in constitutional law, contracts, criminal law, civil procedure and legal practice for courts, firms and corporate counsel.",
         subjects=["Constitutional Law", "Contract Law", "Criminal Law", "Civil Procedure", "Company Law", "Legal Writing"],
         skills=[("Legal Research & Drafting", "technical", 5), ("Courtroom Advocacy", "technical", 4), ("Contract Analysis", "technical", 4),
                 ("Logical Reasoning", "soft", 5), ("Persuasion", "soft", 5), ("Ethical Judgment", "soft", 5)],
         careers=[("Lawyer / Advocate", 8000), ("Corporate Counsel", 12000), ("Legal Consultant", 8000), ("Judicial Officer (CSS/pipeline)", 15000)],
         industries=["Law Firms", "Corporate Legal Departments", "Government", "Judiciary"],
         certs=["Bar Council Enrollment", "LLM Specialization", "International Arbitration Courses"],
         challenges=["Reputation building takes years", "Court delays and case backlogs", "Bar exam and enrollment requirements"]),

    # ---- Social Sciences & Humanities ----
    dict(name="BS Psychology", category="Social Sciences & Humanities", duration="4 years",
         base_salary=85000, growth=0.08, demand=7.8,
         description="BS Psychology covers cognitive, clinical, developmental, social and organizational psychology for roles in counseling, HR, research and mental health.",
         subjects=["Abnormal Psychology", "Cognitive Psychology", "Developmental Psychology", "Social Psychology", "Research Methods", "Organizational Psychology"],
         skills=[("Psychological Assessment", "technical", 4), ("Statistical Analysis", "technical", 4), ("Counseling Techniques", "technical", 4),
                 ("Active Listening", "soft", 5), ("Empathy", "soft", 5), ("Research Design", "soft", 4)],
         careers=[("Clinical Psychologist (with MPhil)", 12000), ("HR Specialist", 6000), ("Research Assistant", 6000), ("School Counselor", 7000)],
         industries=["Healthcare", "Education", "Corporate HR", "NGOs"],
         certs=["Clinical Psychology (MPhil pathway)", "Cognitive Behavioral Therapy (CBT)", "Industrial-Organizational Psychology certs"],
         challenges=["Clinical practice requires postgraduate degree", "Emotional toll of counseling work", "Public awareness of mental health still limited"]),
    dict(name="BS English", category="Social Sciences & Humanities", duration="4 years",
         base_salary=70000, growth=0.05, demand=6.5,
         description="BS English develops literature, linguistics, writing and critical analysis skills for careers in education, media, publishing and communications.",
         subjects=["English Literature", "Linguistics", "Literary Theory", "Creative Writing", "Technical Writing", "Shakespeare & Modern Drama"],
         skills=[("Academic & Creative Writing", "technical", 5), ("Literary Analysis", "technical", 4), ("Editing & Proofreading", "technical", 4),
                 ("Critical Thinking", "soft", 5), ("Communication", "soft", 5), ("Cultural Awareness", "soft", 4)],
         careers=[("Teacher/Lecturer", 6000), ("Content Writer", 5000), ("Editor", 6000), ("Public Relations Officer", 7000)],
         industries=["Education", "Publishing", "Media & Advertising", "Corporate Communications"],
         certs=["TEFL/TESOL Certification", "Digital Content Certifications", "MA English (postgraduate)"],
         challenges=["Often needs postgraduate degree for university roles", "Freelance income unstable", "Must combine with digital skills for media roles"]),
    dict(name="BS Education", category="Social Sciences & Humanities", duration="4 years",
         base_salary=75000, growth=0.06, demand=7.2,
         description="BS Education prepares graduates for teaching, school administration, curriculum development and educational policy roles across formal and informal sectors.",
         subjects=["Educational Psychology", "Curriculum Studies", "Instructional Design", "Assessment & Evaluation", "Philosophy of Education", "Classroom Management"],
         skills=[("Lesson Planning & Delivery", "technical", 5), ("Student Assessment", "technical", 4), ("Classroom Management", "soft", 5),
                 ("Patience", "soft", 5), ("Communication", "soft", 5), ("Digital Learning Tools", "technical", 3)],
         careers=[("School Teacher", 5000), ("School Administrator", 8000), ("Curriculum Developer", 7000), ("Education Officer (NGO/Govt)", 8000)],
         industries=["Schools & Colleges", "Education NGOs", "EdTech Companies", "Government Education Departments"],
         certs=["Teaching License/Certification", "Google for Education", "Montessori/Cambridge Training"],
         challenges=["Public sector salaries modest", "Large class sizes", "Career growth via admin or EdTech pivot"]),

    # ---- Agriculture & Veterinary ----
    dict(name="BS Agriculture", category="Agriculture & Veterinary", duration="4 years",
         base_salary=80000, growth=0.06, demand=7.0,
         description="BS Agriculture covers crop science, soil science, agronomy, agricultural economics and extension services supporting Pakistan's farming sector.",
         subjects=["Crop Production", "Soil Science", "Agricultural Economics", "Plant Pathology", "Irrigation", "Extension Education"],
         skills=[("Crop Management", "technical", 5), ("Soil Analysis", "technical", 4), ("Agricultural Extension", "soft", 4),
                 ("Field Problem Solving", "soft", 4), ("Rural Communication", "soft", 4), ("Record Keeping", "soft", 3)],
         careers=[("Agriculture Officer", 6000), ("Crop Consultant", 7000), ("Agribusiness Manager", 8000), ("Field Supervisor", 6000)],
         industries=["Agricultural Sector", "Food & Agro Industry", "Government (Extension)", "NGOs"],
         certs=["PEC Agriculture Registration", "Agribusiness Certifications", "Modern Farming Techniques Courses"],
         challenges=["Field-based remote work", "Climate change impacts", "Limited private sector openings"]),
    dict(name="DVM", category="Agriculture & Veterinary", duration="5 years",
         base_salary=100000, growth=0.08, demand=8.0,
         description="Doctor of Veterinary Medicine trains vets in animal health, surgery, epidemiology and livestock management for farms, clinics and the livestock industry.",
         subjects=["Animal Anatomy", "Veterinary Physiology", "Animal Diseases", "Veterinary Surgery", "Livestock Production", "Public Health"],
         skills=[("Animal Diagnosis & Treatment", "technical", 5), ("Surgical Skills (animals)", "technical", 5), ("Herd Health Management", "technical", 4),
                 ("Physical Stamina", "soft", 4), ("Owner Communication", "soft", 4), ("Biosecurity Awareness", "soft", 5)],
         careers=[("Veterinary Surgeon", 8000), ("Livestock Officer", 6000), ("Veterinary Public Health Officer", 9000), ("Livestock Farm Manager", 9000)],
         industries=["Livestock Farms", "Veterinary Clinics", "Dairy Industry", "Government Livestock Departments"],
         certs=["PMDC/PVC Registration", "Veterinary Specialization", "Food Safety Certifications"],
         challenges=["Large animal handling risks", "Rural practice locations", "Meat/milk industry awareness growing"]),

    # ---- Arts & Media ----
    dict(name="BS Media and Mass Communication", category="Arts & Media", duration="4 years",
         base_salary=75000, growth=0.10, demand=8.5,
         description="BS Media and Mass Communication covers journalism, broadcasting, advertising, digital media and strategic communication for media houses and corporate communications.",
         subjects=["Media Laws & Ethics", "News Reporting", "Broadcast Journalism", "Advertising & PR", "Digital Media", "Media Research"],
         skills=[("News Writing & Reporting", "technical", 5), ("Video Production & Editing", "technical", 4), ("Social Media Management", "technical", 5),
                 ("Public Speaking", "soft", 4), ("Networking", "soft", 5), ("Creative Thinking", "soft", 5)],
         careers=[("Journalist", 6000), ("Digital Content Creator", 7000), ("PR Specialist", 8000), ("Media Planner", 9000)],
         industries=["TV/Radio Channels", "Digital Media Platforms", "Advertising Agencies", "Corporate Communications"],
         certs=["Digital Marketing Certifications", "Adobe Premiere/After Effects", "Google Analytics"],
         challenges=["Unstable starting salaries", "Reputation and portfolio critical", "Freelance vs salaried paths diverge"]),
    dict(name="Bachelor of Architecture", category="Arts & Media", duration="5 years",
         base_salary=110000, growth=0.08, demand=7.8,
         description="Bachelor of Architecture trains students in architectural design, building technology, structures, history and professional practice, leading to PAC licensing.",
         subjects=["Architectural Design", "Building Construction", "Structural Systems", "History of Architecture", "Building Services", "Urban Planning"],
         skills=[("AutoCAD/Revit/SketchUp", "technical", 5), ("Architectural Design", "technical", 5), ("3D Visualization", "technical", 4),
                 ("Creative Vision", "soft", 5), ("Client Communication", "soft", 4), ("Attention to Detail", "soft", 5)],
         careers=[("Architect", 8000), ("Urban Designer", 8000), ("Interior Designer", 7000), ("Project Architect (senior)", 15000)],
         industries=["Architecture Firms", "Construction", "Real Estate Development", "Government Planning"],
         certs=["PAC (Pakistan Council of Architects) License", "LEED Certification", "BIM Certifications"],
         challenges=["Requires PAC registration to practice independently", "Project cycles slow", "Design competition pressure"]),
    dict(name="BS Environmental Sciences", category="Agriculture & Veterinary", duration="4 years",
         base_salary=85000, growth=0.08, demand=7.5,
         description="BS Environmental Sciences covers ecology, environmental monitoring, climate change, waste management and environmental policy for sustainability careers.",
         subjects=["Environmental Ecology", "Environmental Monitoring", "Climate Change Science", "Waste Management", "Environmental Law", "GIS & Remote Sensing"],
         skills=[("Environmental Impact Assessment", "technical", 4), ("GIS/Remote Sensing", "technical", 4), ("Data Analysis", "technical", 4),
                 ("Field Research", "technical", 4), ("Policy Understanding", "soft", 4), ("Report Writing", "soft", 4)],
         careers=[("Environmental Analyst", 7000), ("EIA Consultant", 8000), ("Sustainability Officer", 9000), ("Environmental Inspector", 7000)],
         industries=["Environmental Consulting", "Government (EPA)", "NGOs & Development", "Mining & Industry Compliance"],
         certs=["ISO 14001 Lead Auditor", "GIS Certifications", "EIA Professional Courses"],
         challenges=["Field work in remote areas", "Funding-dependent NGO roles", "Regulatory enforcement gaps"]),
]

HISTORY_YEARS = list(range(2018, 2026))  # historical window used for training


def _history_series(base_salary, growth, years):
    """Generate an illustrative monthly-salary series ending near base_salary."""
    # Back-calculate: latest year equals base_salary, earlier years grow forward.
    n = len(years)
    latest = base_salary
    salaries = [latest]
    for _ in range(n - 1):
        salaries.append(salaries[-1] / (1 + growth))
    salaries = list(reversed(salaries))  # oldest -> newest
    return [round(s, -2) for s in salaries]


def seed_database(force=False):
    """Populate the database with degree information. Skips if already seeded."""
    init_database()
    existing = query("SELECT COUNT(*) AS c FROM degrees")
    if existing and existing[0]["c"] > 0 and not force:
        return False

    with get_connection() as conn:
        conn.execute("DELETE FROM predictions")
        for table in ["challenges", "certifications", "industries", "careers",
                      "skills", "subjects", "salary_history", "employment_history", "degrees"]:
            conn.execute(f"DELETE FROM {table}")
        conn.commit()

    for d in DEGREES:
        degree_id = execute(
            """INSERT INTO degrees (name, category, description, duration, salary_band,
                                     demand_index, growth_rate)
               VALUES (?,?,?,?,?,?,?)""",
            (d["name"], d["category"], d["description"], d["duration"],
             f"PKR {int(d['base_salary']*0.6/1000)}k-{int(d['base_salary']*1.8/1000)}k monthly",
             d["demand"], d["growth"]))

        execute_many("INSERT INTO subjects (degree_id, subject_name) VALUES (?,?)",
                     [(degree_id, s) for s in d["subjects"]])
        execute_many("INSERT INTO skills (degree_id, skill_name, skill_type, importance) VALUES (?,?,?,?)",
                     [(degree_id, n, t, imp) for n, t, imp in d["skills"]])
        execute_many("INSERT INTO careers (degree_id, job_title, job_positions) VALUES (?,?,?)",
                     [(degree_id, j, p) for j, p in d["careers"]])
        execute_many("INSERT INTO industries (degree_id, industry_name) VALUES (?,?)",
                     [(degree_id, i) for i in d["industries"]])
        execute_many("INSERT INTO certifications (degree_id, cert_name) VALUES (?,?)",
                     [(degree_id, c) for c in d["certs"]])
        execute_many("INSERT INTO challenges (degree_id, challenge) VALUES (?,?)",
                     [(degree_id, c) for c in d["challenges"]])

        salaries = _history_series(d["base_salary"], d["growth"], HISTORY_YEARS)
        execute_many(
            """INSERT INTO salary_history (degree_id, year, avg_monthly_salary, data_source)
               VALUES (?,?,?,?)""",
            [(degree_id, y, s, "estimated") for y, s in zip(HISTORY_YEARS, salaries)])

        # Employment index: 100 at 2025, growing backwards by growth rate.
        emp_latest = 100.0
        emp_series = [emp_latest]
        for _ in range(len(HISTORY_YEARS) - 1):
            emp_series.append(emp_series[-1] / (1 + d["growth"] * 0.8))
        emp_series = list(reversed(emp_series))
        openings = int(d["demand"] * 1200)
        execute_many(
            """INSERT INTO employment_history (degree_id, year, employment_index,
                                              job_openings_est, data_source)
               VALUES (?,?,?,?,?)""",
            [(degree_id, y, round(v, 2), int(openings * v / 100), "estimated")
             for y, v in zip(HISTORY_YEARS, emp_series)])

    return True


if __name__ == "__main__":
    seeded = seed_database(force=True)
    print("Seeded:", seeded, "| degrees:", len(DEGREES))
