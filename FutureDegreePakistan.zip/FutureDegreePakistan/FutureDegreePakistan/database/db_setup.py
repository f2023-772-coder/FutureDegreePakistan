"""Database schema creation for FutureDegree Pakistan."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from db_connection import get_connection, DB_DIR

SCHEMA = """
CREATE TABLE IF NOT EXISTS degrees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    duration TEXT,
    salary_band TEXT,
    demand_index REAL DEFAULT 5.0,
    growth_rate REAL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    subject_name TEXT NOT NULL,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    skill_name TEXT NOT NULL,
    skill_type TEXT DEFAULT 'technical',
    importance REAL DEFAULT 3.0,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS careers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    job_title TEXT NOT NULL,
    job_positions INTEGER DEFAULT 0,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS industries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    industry_name TEXT NOT NULL,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS certifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    cert_name TEXT NOT NULL,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS salary_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    year INTEGER NOT NULL,
    avg_monthly_salary REAL NOT NULL,
    data_source TEXT DEFAULT 'estimated',
    UNIQUE(degree_id, year),
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS employment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    year INTEGER NOT NULL,
    employment_index REAL NOT NULL,
    job_openings_est INTEGER DEFAULT 0,
    data_source TEXT DEFAULT 'estimated',
    UNIQUE(degree_id, year),
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    challenge TEXT NOT NULL,
    FOREIGN KEY (degree_id) REFERENCES degrees(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    degree_id INTEGER NOT NULL,
    target_year INTEGER NOT NULL,
    predicted_salary REAL,
    predicted_employment REAL,
    salary_growth_pct REAL,
    employment_growth_pct REAL,
    model_used TEXT,
    metrics_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


def init_database():
    """Create all tables if they do not exist."""
    os.makedirs(DB_DIR, exist_ok=True)
    with get_connection() as conn:
        conn.executescript(SCHEMA)
        conn.commit()
    return True


if __name__ == "__main__":
    init_database()
    print("Database initialized at:", os.path.join(DB_DIR, "futuredegree.db"))
