"""Shared base class and widgets for all pages."""
import customtkinter as ctk

from helpers import COLORS


class PageBase(ctk.CTkScrollableFrame):
    def __init__(self, master, app=None, **kwargs):
        super().__init__(master, fg_color=COLORS["bg"], **kwargs)
        self.app = app

    def card(self, parent=None, **kwargs):
        """Create a rounded white card frame."""
        parent = parent or self
        return ctk.CTkFrame(parent, fg_color=COLORS["card"], corner_radius=14,
                            border_width=1, border_color="#E5E9F0", **kwargs)

    def title(self, text, parent=None):
        parent = parent or self
        return ctk.CTkLabel(parent, text=text, font=("Segoe UI", 22, "bold"),
                            text_color=COLORS["primary"])

    def subtitle(self, text, parent=None):
        parent = parent or self
        return ctk.CTkLabel(parent, text=text, font=("Segoe UI", 12),
                            text_color=COLORS["muted"])

    def section_label(self, text, parent=None):
        parent = parent or self
        lbl = ctk.CTkLabel(parent, text=text.upper(), font=("Segoe UI", 11, "bold"),
                           text_color=COLORS["accent"])
        lbl.pack(anchor="w", pady=(10, 4))
        return lbl

    def info_label(self, text, parent=None, bold=False):
        parent = parent or self
        return ctk.CTkLabel(parent, text=text, font=("Segoe UI", 12, "bold" if bold else "normal"),
                            text_color=COLORS["text"], wraplength=900,
                            justify="left")

    def error_box(self, message):
        box = self.card()
        box.pack(fill="x", pady=20)
        ctk.CTkLabel(box, text="Something went wrong", font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["danger"]).pack(pady=(12, 4))
        ctk.CTkLabel(box, text=str(message), font=("Segoe UI", 11),
                     text_color=COLORS["muted"], wraplength=700).pack(pady=(0, 12))
