"""Job Market Trends page: historical vs predicted employment trends."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS
import prediction_service
import charts


class TrendsPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._degree_var = None
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        self.title("Job Market Trends", self).pack(anchor="w", pady=(0, 4))
        self.subtitle("Historical and predicted employment trends across degree categories.",
                      self).pack(anchor="w", pady=(0, 12))

        data = prediction_service.market_trends()

        # Controls: pick a degree for detailed trend
        ctrl = self.card()
        ctrl.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(ctrl, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=10)
        ctk.CTkLabel(row, text="Degree trend:", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 10))
        names = [d["name"] for d in prediction_service.list_degrees()]
        self._degree_var = ctk.StringVar(value=names[0] if names else "")
        menu = ctk.CTkOptionMenu(row, variable=self._degree_var, values=names,
                                 width=320, height=34)
        menu.pack(side="left")
        chart_host = ctk.CTkFrame(ctrl, fg_color="transparent")
        chart_host.pack(fill="x", padx=10, pady=(0, 10))

        def draw():
            for w in chart_host.winfo_children():
                w.destroy()
            try:
                det = prediction_service.degree_details(self._degree_var.get())
                emp = det["employment_history"]
                proj = []
                # project employment index forward using growth rate
                d = det["degree"]
                last_year, last_val = emp[-1]["year"], emp[-1]["employment_index"]
                g = float(d["growth_rate"] or 0.05) * 0.8
                for y in range(1, 6):
                    proj.append({"year": last_year + y,
                                 "index": round(last_val * ((1 + g) ** y), 2)})
                fig2 = charts.line_chart(
                    [e["year"] for e in emp] + [p["year"] for p in proj],
                    {"Index": [e["employment_index"] for e in emp] +
                              [p["index"] for p in proj]},
                    f"{self._degree_var.get()} — Employment Index (Historical + Predicted)",
                    ylabel="Index (2025=100)")
                charts.embed_figure(chart_host, fig2)
            except Exception as e:
                ctk.CTkLabel(chart_host, text=f"Chart error: {e}",
                             text_color=COLORS["danger"]).pack()

        menu.configure(command=lambda v: draw())
        self.after(50, draw)

        # Aggregate charts row
        row1 = ctk.CTkFrame(self, fg_color="transparent")
        row1.pack(fill="x", pady=6)

        c1 = self.card(row1)
        c1.pack(side="left", fill="both", expand=True, padx=6)
        if data["employment"]:
            fig = charts.line_chart(
                [r["year"] for r in data["employment"]],
                {"Avg Employment Index": [r["avg_emp"] for r in data["employment"]],
                 "Job Openings (est.)": [r["openings"] / 10000 for r in data["employment"]]},
                "National Employment Trends (Aggregated)",
                ylabel="Index / openings (10k)")
            charts.embed_figure(c1, fig)

        c2 = self.card(row1)
        c2.pack(side="left", fill="both", expand=True, padx=6)
        if data["salary"]:
            fig = charts.line_chart(
                [r["year"] for r in data["salary"]],
                {"Avg Salary (PKR '000)": [r["avg_salary"] / 1000 for r in data["salary"]]},
                "Average Salary Trend (PKR '000/month)")
            charts.embed_figure(c2, fig)

        # Category demand table
        card = self.card()
        card.pack(fill="x", pady=6)
        ctk.CTkLabel(card, text="Career Category Outlook",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
        for ci, h in enumerate(["Category", "Avg Demand (1-10)", "Avg Growth (%/yr)", "Outlook"]):
            ctk.CTkLabel(card, text=h, font=("Segoe UI", 11, "bold"),
                         text_color=COLORS["muted"], anchor="w").grid(
                row=0, column=ci, padx=12, pady=(4, 6), sticky="w")
        for ri, cat in enumerate(data["categories"], start=1):
            outlook = ("High Growth" if (cat["avg_growth"] or 0) > 0.09 else
                       "Moderate" if (cat["avg_growth"] or 0) > 0.06 else "Slower Growth")
            vals = [cat["category"], f"{cat['avg_demand']:.1f}",
                    f"{(cat['avg_growth'] or 0)*100:.1f}%", outlook]
            for ci, v in enumerate(vals):
                ctk.CTkLabel(card, text=str(v), font=("Segoe UI", 11),
                             text_color=COLORS["text"], anchor="w").grid(
                    row=ri, column=ci, padx=12, pady=3, sticky="w")
        ctk.CTkLabel(card, text="", height=10).grid(row=len(data["categories"]) + 1,
                                                  column=0)

        note = self.card()
        note.pack(fill="x", pady=(6, 0))
        ctk.CTkLabel(note, text=data["note"], font=("Segoe UI", 10, "italic"),
                     text_color=COLORS["warning"], wraplength=1100,
                     justify="left").pack(anchor="w", padx=16, pady=12)
