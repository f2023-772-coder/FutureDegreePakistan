"""Settings page: data management, retraining, app info."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS
import prediction_service
import data_processing


class SettingsPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._status = ctk.StringVar(value="Ready.")
        self._build()

    def _build(self):
        self.title("Settings", self).pack(anchor="w", pady=(0, 10))

        card = self.card()
        card.pack(fill="x", pady=6)
        ctk.CTkLabel(card, text="Data Management",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 4))

        def btn(text, cmd):
            return ctk.CTkButton(card, text=text, height=36, width=280,
                                 corner_radius=10, fg_color=COLORS["accent"],
                                 hover_color=COLORS["primary"], command=cmd)

        btn("Rebuild datasets from database", self._rebuild_datasets).pack(
            anchor="w", padx=18, pady=4)
        btn("Retrain ML models", self._retrain).pack(anchor="w", padx=18, pady=4)
        btn("Re-seed database (reset to defaults)", self._reseed).pack(
            anchor="w", padx=18, pady=(4, 12))

        ctk.CTkLabel(card, textvariable=self._status, font=("Segoe UI", 11),
                     text_color=COLORS["muted"]).pack(anchor="w", padx=18, pady=(0, 12))

        info = self.card()
        info.pack(fill="x", pady=6)
        ctk.CTkLabel(info, text="About this data",
                     font=("Segoe UI", 14, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(12, 4))
        ctk.CTkLabel(info,
                     text="Historical salary and employment series are simulated "
                          "illustrative estimates stored locally in SQLite and CSV "
                          "datasets. To add real Pakistani data later, append rows to "
                          "datasets/salary_data.csv and datasets/employment_data.csv, "
                          "then use 'Retrain ML models'.",
                     font=("Segoe UI", 11), text_color=COLORS["muted"],
                     wraplength=1100, justify="left").pack(anchor="w", padx=18, pady=(0, 14))

    def _rebuild_datasets(self):
        try:
            data_processing.rebuild_datasets()
            self._status.set("Datasets rebuilt successfully.")
        except Exception as e:
            self._status.set(f"Error: {e}")

    def _retrain(self):
        try:
            prediction_service._retrain_models()
            prediction_service._models_loaded = True
            self._status.set("Models retrained and saved.")
        except Exception as e:
            self._status.set(f"Error: {e}")

    def _reseed(self):
        try:
            prediction_service.seed_database(force=True)
            prediction_service._retrain_models()
            prediction_service._models_loaded = True
            self._status.set("Database re-seeded and models retrained.")
        except Exception as e:
            self._status.set(f"Error: {e}")
