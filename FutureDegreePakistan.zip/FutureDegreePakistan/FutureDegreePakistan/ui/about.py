"""About Project page."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS


class AboutPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._build()

    def _build(self):
        self.title("About Project", self).pack(anchor="w", pady=(0, 10))

        card = self.card()
        card.pack(fill="x", pady=6)
        ctk.CTkLabel(card, text="FutureDegree Pakistan",
                     font=("Segoe UI", 18, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(14, 2))
        ctk.CTkLabel(card,
                     text="An Offline Big Data-Based Educational and Career Prediction System.",
                     font=("Segoe UI", 12), text_color=COLORS["accent"]).pack(anchor="w", padx=18, pady=(0, 10))

        body = (
            "FutureDegree Pakistan helps Pakistani students choose university degrees based on "
            "career opportunities, employment demand, expected salaries, industry trends and "
            "future growth predictions.\n\n"
            "The application stores degree information in a local SQLite database, processes "
            "historical salary and employment datasets with Pandas, and generates 1–10 year "
            "career predictions using Linear Regression and Random Forest models trained with "
            "scikit-learn.\n\n"
            "IMPORTANT: The historical data bundled with this project is simulated/illustrative "
            "and is NOT official Pakistani employment statistics. All predictions are estimates "
            "for guidance only and are not guaranteed.\n\n"
            "Technology stack: Python 3.11+, CustomTkinter, SQLite, Pandas, NumPy, "
            "Scikit-learn, Matplotlib, Joblib. Runs fully offline."
        )
        ctk.CTkLabel(card, text=body, font=("Segoe UI", 12),
                     text_color=COLORS["text"], wraplength=1100,
                     justify="left").pack(anchor="w", padx=18, pady=(0, 16))
