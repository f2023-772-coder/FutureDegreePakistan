"""Skills Recommendations page."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS
import recommendation_service
import prediction_service


class SkillsPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._degree_var = ctk.StringVar()
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        self.title("Skills Recommendations", self).pack(anchor="w", pady=(0, 4))
        self.subtitle("Technical, soft and industry skills plus certifications per degree.",
                      self).pack(anchor="w", pady=(0, 12))

        names = [d["name"] for d in prediction_service.list_degrees()]
        if names:
            self._degree_var.set(names[0])

        ctrl = self.card()
        ctrl.pack(fill="x", pady=(0, 12))
        row = ctk.CTkFrame(ctrl, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=10)
        ctk.CTkLabel(row, text="Degree:", font=("Segoe UI", 12, "bold"),
                     text_color=COLORS["text"]).pack(side="left", padx=(0, 10))
        menu = ctk.CTkOptionMenu(row, variable=self._degree_var, values=names,
                                 width=340, height=36,
                                 command=lambda v: self._render())
        menu.pack(side="left")

        self._host = ctk.CTkFrame(self, fg_color="transparent")
        self._host.pack(fill="both", expand=True)
        self._render()

        # Rising skills section
        rise = self.card()
        rise.pack(fill="x", pady=10)
        ctk.CTkLabel(rise, text="Skills Becoming More Important for Future Employment",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
        for r in recommendation_service.rising_skills_report()[:12]:
            ctk.CTkLabel(rise,
                         text=f"• {r['skill_name']}  ({r['skill_type']}, avg importance {r['avg_imp']:.1f}/5)",
                         font=("Segoe UI", 11), text_color=COLORS["text"],
                         anchor="w").pack(anchor="w", padx=18, pady=1)
        ctk.CTkLabel(rise, text="", height=10).pack()

    def _render(self):
        for w in self._host.winfo_children():
            w.destroy()
        name = self._degree_var.get()
        skills = recommendation_service.skills_for_degree(name)
        certs = recommendation_service.certifications_for_degree(name)

        body = ctk.CTkFrame(self._host, fg_color="transparent")
        body.pack(fill="x")
        cols = [ctk.CTkFrame(body, fg_color="transparent") for _ in range(3)]
        for i, c in enumerate(cols):
            c.pack(side="left", fill="both", expand=True, padx=4)

        def fill(parent, title, items):
            card = self.card(parent)
            card.pack(fill="x", pady=6)
            ctk.CTkLabel(card, text=title, font=("Segoe UI", 13, "bold"),
                         text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
            for it in items:
                label = it["skill_name"] if isinstance(it, dict) else it
                sub = f" (importance {it['importance']}/5)" if isinstance(it, dict) else ""
                ctk.CTkLabel(card, text=f"• {label}{sub}", font=("Segoe UI", 12),
                             text_color=COLORS["text"], wraplength=340,
                             justify="left").pack(anchor="w", padx=16, pady=1)
            ctk.CTkLabel(card, text="", height=8).pack()

        fill(cols[0], "Technical Skills", skills["technical"])
        fill(cols[1], "Soft Skills", skills["soft"])
        fill(cols[2], "Industry Skills", skills["industry"] or skills["technical"][:3])

        ccard = self.card(self._host)
        ccard.pack(fill="x", pady=6)
        ctk.CTkLabel(ccard, text="Recommended Certifications", font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
        for c in certs:
            ctk.CTkLabel(ccard, text=f"• {c['cert_name']}", font=("Segoe UI", 12),
                         text_color=COLORS["text"], anchor="w").pack(anchor="w", padx=18, pady=1)
        ctk.CTkLabel(ccard, text="", height=10).pack()
