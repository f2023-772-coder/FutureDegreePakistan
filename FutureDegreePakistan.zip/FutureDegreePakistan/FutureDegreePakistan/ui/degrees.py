"""Explore Degrees page: searchable/filterable degree cards + detail profiles."""
import customtkinter as ctk

import helpers  # noqa: F401
from base import PageBase
from helpers import COLORS, format_pkr
import prediction_service
import charts


class DegreesPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        self._degrees = []
        self._search_var = ctk.StringVar()
        self._category_var = ctk.StringVar(value="All")
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    # ---------------- List view ----------------
    def _build(self):
        self._degrees = prediction_service.list_degrees()
        self._categories = ["All"] + sorted({d["category"] for d in self._degrees})

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", pady=(0, 10))
        self.title("Explore Degrees", header).pack(side="left")
        self.subtitle(f"{len(self._degrees)} degree programs", header).pack(side="left", padx=12, pady=18)

        controls = ctk.CTkFrame(self, fg_color="transparent")
        controls.pack(fill="x", pady=(0, 10))
        self.search = ctk.CTkEntry(controls, textvariable=self._search_var,
                                   placeholder_text="Search degrees...",
                                   width=280, height=36, corner_radius=10)
        self.search.pack(side="left", padx=(0, 10))
        self.search.bind("<KeyRelease>", lambda e: self._render_grid())

        self.cat_menu = ctk.CTkOptionMenu(controls, variable=self._category_var,
                                          values=self._categories, width=220, height=36,
                                          command=lambda v: self._render_grid())
        self.cat_menu.pack(side="left")

        self.grid_host = ctk.CTkFrame(self, fg_color="transparent")
        self.grid_host.pack(fill="both", expand=True)
        self._render_grid()

    def _render_grid(self):
        for w in self.grid_host.winfo_children():
            w.destroy()
        query_text = self._search_var.get().strip().lower()
        cat = self._category_var.get()

        filtered = [d for d in self._degrees
                    if (cat == "All" or d["category"] == cat)
                    and (not query_text or query_text in d["name"].lower())]

        if not filtered:
            ctk.CTkLabel(self.grid_host, text="No degrees match your search.",
                         text_color=COLORS["muted"]).pack(pady=40)
            return

        # 3-column grid of cards
        for i, d in enumerate(filtered):
            card = self.card(self.grid_host)
            card.grid(row=i // 3, column=i % 3, padx=6, pady=6, sticky="nsew")
            self.grid_host.grid_columnconfigure(i % 3, weight=1)
            self.grid_host.grid_rowconfigure(i // 3, weight=0)

            ctk.CTkLabel(card, text=d["name"], font=("Segoe UI", 14, "bold"),
                         text_color=COLORS["primary"], wraplength=300,
                         justify="left").pack(anchor="w", padx=14, pady=(12, 2))
            ctk.CTkLabel(card, text=f"{d['category']} • {d['duration']}",
                         font=("Segoe UI", 11), text_color=COLORS["accent"]).pack(anchor="w", padx=14)
            ctk.CTkLabel(card,
                         text=d["description"][:140] + ("..." if len(d["description"]) > 140 else ""),
                         font=("Segoe UI", 11), text_color=COLORS["muted"],
                         wraplength=300, justify="left").pack(anchor="w", padx=14, pady=(4, 8))
            ctk.CTkButton(card, text="View Profile", height=30, corner_radius=8,
                          fg_color=COLORS["accent"], hover_color=COLORS["primary"],
                          command=lambda n=d["name"]: self._show_detail(n)
                          ).pack(anchor="w", padx=14, pady=(0, 12))

    # ---------------- Detail view ----------------
    def _show_detail(self, name):
        for w in self.winfo_children():
            w.destroy()

        back = ctk.CTkButton(self, text="← Back to Degrees", width=160, height=34,
                             corner_radius=10, fg_color=COLORS["primary"],
                             command=self._build)
        back.pack(anchor="w", pady=(0, 10))

        try:
            det = prediction_service.degree_details(name)
        except Exception as e:
            self.error_box(e)
            return
        if not det:
            self.error_box("Degree not found.")
            return

        d = det["degree"]

        head = self.card()
        head.pack(fill="x", pady=(0, 10))
        ctk.CTkLabel(head, text=d["name"], font=("Segoe UI", 20, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(14, 2))
        ctk.CTkLabel(head,
                     text=f"{d['category']}  •  Duration: {d['duration']}  •  Salary band: {d['salary_band']}  •  Demand: {d['demand_index']}/10",
                     font=("Segoe UI", 12), text_color=COLORS["accent"]).pack(anchor="w", padx=18, pady=(0, 4))
        ctk.CTkLabel(head, text=d["description"], font=("Segoe UI", 12),
                     text_color=COLORS["text"], wraplength=1100,
                     justify="left").pack(anchor="w", padx=18, pady=(0, 14))

        # Two-column body
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="x")
        left = ctk.CTkFrame(body, fg_color="transparent")
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        right = ctk.CTkFrame(body, fg_color="transparent")
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))

        def bullet_list(parent, title, items):
            card = self.card(parent)
            card.pack(fill="x", pady=6)
            ctk.CTkLabel(card, text=title, font=("Segoe UI", 13, "bold"),
                         text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 4))
            for it in items:
                ctk.CTkLabel(card, text=f"• {it}", font=("Segoe UI", 12),
                             text_color=COLORS["text"], wraplength=500,
                             justify="left").pack(anchor="w", padx=18, pady=1)
            ctk.CTkLabel(card, text="", height=8).pack()

        bullet_list(left, "Important Subjects",
                    [s["subject_name"] for s in det["subjects"]])
        bullet_list(left, "Required Skills",
                    [f"{s['skill_name']} ({s['skill_type']})" for s in det["skills"]])
        bullet_list(left, "Professional Certifications",
                    [c["cert_name"] for c in det["certifications"]])
        bullet_list(left, "Career Growth Opportunities",
                    [f"{c['job_title']} — ~{c['job_positions']:,} positions" for c in det["careers"]])

        bullet_list(right, "Career Opportunities",
                    [c["job_title"] for c in det["careers"]])
        bullet_list(right, "Available Job Positions",
                    [f"{c['job_title']}: {c['job_positions']:,}" for c in det["careers"]])
        bullet_list(right, "Relevant Industries",
                    [i["industry_name"] for i in det["industries"]])
        bullet_list(right, "Job Market Challenges",
                    [c["challenge"] for c in det["challenges"]])

        # Salary chart
        sal_card = self.card()
        sal_card.pack(fill="x", pady=10)
        ctk.CTkLabel(sal_card, text="Salary Trend (Estimated, PKR/month)",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(10, 2))
        hist = det["salary_history"]
        if hist:
            proj = prediction_service.salary_projection(name, 5)
            fig = charts.salary_projection_chart(
                [h["year"] for h in hist], [h["avg_monthly_salary"] for h in hist],
                proj, f"{name} — Historical & 5-Year Projection")
            charts.embed_figure(sal_card, fig)
        ctk.CTkLabel(sal_card,
                     text="Estimated values based on simulated data — for guidance only.",
                     font=("Segoe UI", 10), text_color=COLORS["muted"]
                     ).pack(anchor="w", padx=14, pady=(0, 10))
