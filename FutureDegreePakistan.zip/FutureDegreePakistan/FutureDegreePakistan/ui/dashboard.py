"""Dashboard page: KPIs and overview charts."""
import customtkinter as ctk

import helpers  # noqa: F401  sets sys.path
from base import PageBase
from helpers import COLORS, format_pkr_short
import prediction_service
import charts


class DashboardPage(PageBase):
    def __init__(self, master, app=None):
        super().__init__(master, app=app)
        try:
            self._build()
        except Exception as e:
            self.error_box(e)

    def _build(self):
        # Welcome banner
        banner = self.card()
        banner.pack(fill="x", pady=(0, 14))
        ctk.CTkLabel(banner, text="Welcome to FutureDegree Pakistan",
                     font=("Segoe UI", 20, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=18, pady=(14, 2))
        ctk.CTkLabel(banner,
                     text="Explore Your Future Career — data-driven degree guidance for Pakistani students.",
                     font=("Segoe UI", 12), text_color=COLORS["muted"]).pack(anchor="w", padx=18, pady=(0, 14))

        degrees = prediction_service.list_degrees()
        categories = {d["category"] for d in degrees}
        industries = set()
        for d in degrees:
            det = prediction_service.degree_details(d["name"])
            industries.update(i["industry_name"] for i in det["industries"])

        # KPI cards
        kpis = [
            ("Total Degree Programs", str(len(degrees))),
            ("Career Categories", str(len(categories))),
            ("Available Industries", str(len(industries))),
            ("Prediction Period", "1–10 Years"),
        ]
        kpi_row = ctk.CTkFrame(self, fg_color="transparent")
        kpi_row.pack(fill="x", pady=(0, 14))
        for label, value in kpis:
            card = self.card(kpi_row)
            card.pack(side="left", fill="both", expand=True, padx=6)
            ctk.CTkLabel(card, text=value, font=("Segoe UI", 26, "bold"),
                         text_color=COLORS["accent"]).pack(pady=(14, 0))
            ctk.CTkLabel(card, text=label, font=("Segoe UI", 11),
                         text_color=COLORS["muted"]).pack(pady=(0, 12))

        # Charts row 1: category distribution + top salaries
        row1 = ctk.CTkFrame(self, fg_color="transparent")
        row1.pack(fill="x", pady=6)

        cat_counts = {}
        for d in degrees:
            cat_counts[d["category"]] = cat_counts.get(d["category"], 0) + 1

        c1 = self.card(row1)
        c1.pack(side="left", fill="both", expand=True, padx=6)
        fig = charts.pie_chart(list(cat_counts.keys()), list(cat_counts.values()),
                               "Degree Category Distribution")
        charts.embed_figure(c1, fig)

        # salary comparison: top 10 degrees by current salary
        sal_rows = sorted(prediction_service.salary_analysis(),
                          key=lambda r: r["current_salary"], reverse=True)[:10]
        c2 = self.card(row1)
        c2.pack(side="left", fill="both", expand=True, padx=6)
        fig = charts.bar_chart([r["name"].replace("BS ", "").replace("Bachelor of ", "")
                                for r in sal_rows],
                               [r["current_salary"] / 1000 for r in sal_rows],
                               "Highest Expected Salaries (PKR '000/month)",
                               horizontal=True)
        charts.embed_figure(c2, fig)

        # Charts row 2: demand + growth
        row2 = ctk.CTkFrame(self, fg_color="transparent")
        row2.pack(fill="x", pady=6)

        top_demand = sorted(degrees, key=lambda d: -(d["demand_index"] or 0))[:10]
        c3 = self.card(row2)
        c3.pack(side="left", fill="both", expand=True, padx=6)
        fig = charts.bar_chart([d["name"].replace("BS ", "") for d in top_demand],
                               [d["demand_index"] for d in top_demand],
                               "Future Job Demand Index (1-10)",
                               color=COLORS["success"])
        charts.embed_figure(c3, fig)

        top_growth = sorted(degrees, key=lambda d: -(d["growth_rate"] or 0))[:10]
        c4 = self.card(row2)
        c4.pack(side="left", fill="both", expand=True, padx=6)
        fig = charts.bar_chart([d["name"].replace("BS ", "") for d in top_growth],
                               [(d["growth_rate"] or 0) * 100 for d in top_growth],
                               "Annual Salary Growth Rate (%)",
                               color=COLORS["warning"])
        charts.embed_figure(c4, fig)

        # Lists row
        row3 = ctk.CTkFrame(self, fg_color="transparent")
        row3.pack(fill="x", pady=6)

        popular = self.card(row3)
        popular.pack(side="left", fill="both", expand=True, padx=6)
        ctk.CTkLabel(popular, text="Popular Degree Programs",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(12, 6))
        for d in sorted(degrees, key=lambda x: -(x["demand_index"] or 0))[:8]:
            ctk.CTkLabel(popular, text=f"• {d['name']}  ({d['category']})",
                         font=("Segoe UI", 12), text_color=COLORS["text"],
                         anchor="w").pack(anchor="w", padx=18, pady=1)
        ctk.CTkLabel(popular, text="", height=8).pack()

        highest = self.card(row3)
        highest.pack(side="left", fill="both", expand=True, padx=6)
        ctk.CTkLabel(highest, text="Highest Expected Salary Degrees",
                     font=("Segoe UI", 13, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=14, pady=(12, 6))
        for r in sal_rows[:8]:
            ctk.CTkLabel(highest,
                         text=f"• {r['name']} — {format_pkr_short(r['current_salary'])}/mo",
                         font=("Segoe UI", 12), text_color=COLORS["text"],
                         anchor="w").pack(anchor="w", padx=18, pady=1)
        ctk.CTkLabel(highest, text="", height=8).pack()

        note = self.card()
        note.pack(fill="x", pady=(10, 0))
        ctk.CTkLabel(note,
                     text="All salary figures are illustrative estimates derived from simulated historical data — "
                          "not official Pakistani employment statistics. Predictions are not guaranteed.",
                     font=("Segoe UI", 10), text_color=COLORS["muted"],
                     wraplength=1000, justify="left").pack(anchor="w", padx=16, pady=12)
