"""Skills and career recommendation service."""
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE_DIR, "database"))

from db_connection import query


def skills_for_degree(degree_name):
    rows = query("""SELECT s.* FROM skills s JOIN degrees d ON d.id=s.degree_id
                    WHERE d.name=? ORDER BY s.importance DESC, s.skill_type""",
                 (degree_name,))
    grouped = {"technical": [], "soft": [], "industry": []}
    for r in rows:
        key = r["skill_type"] if r["skill_type"] in grouped else "technical"
        grouped[key].append(r)
    return grouped


def certifications_for_degree(degree_name):
    return query("""SELECT c.cert_name FROM certifications c
                    JOIN degrees d ON d.id=c.degree_id WHERE d.name=?""",
                 (degree_name,))


def recommend_for_interests(interests):
    """Recommend degrees matching free-text interests (simple keyword match)."""
    degrees = query("SELECT name, category, description FROM degrees")
    interests_l = [i.lower() for i in interests if i.strip()]
    scored = []
    for d in degrees:
        text = f"{d['name']} {d['category']} {d['description']}".lower()
        score = sum(1 for i in interests_l if i in text)
        if score:
            scored.append((score, d))
    scored.sort(key=lambda x: -x[0])
    return [d for _, d in scored[:5]] or degrees[:5]


def rising_skills_report():
    """Skills ranked by importance across all degrees (future relevance proxy)."""
    rows = query("""SELECT skill_name, skill_type, AVG(importance) avg_imp, COUNT(*) cnt
                    FROM skills GROUP BY skill_name, skill_type
                    ORDER BY avg_imp DESC, cnt DESC LIMIT 25""")
    return rows
