"""Data loading and preprocessing for the dataset CSVs.

Provides a clean, expandable pipeline: drop missing values, remove
duplicates, and produce feature frames for model training.
"""
import os

import pandas as pd

DATASETS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datasets")


def load_csv(name):
    """Load a dataset CSV, returning an empty DataFrame if missing."""
    path = os.path.join(DATASETS_DIR, name)
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path)


def clean_dataframe(df):
    """Drop duplicates and missing values, reset index."""
    if df.empty:
        return df
    return df.drop_duplicates().dropna().reset_index(drop=True)


def salary_frame():
    df = clean_dataframe(load_csv("salary_data.csv"))
    if df.empty:
        return df
    df["year"] = df["year"].astype(int)
    df["salary_pkr"] = pd.to_numeric(df["salary_pkr"], errors="coerce")
    return df.dropna(subset=["salary_pkr"])


def employment_frame():
    df = clean_dataframe(load_csv("employment_data.csv"))
    if df.empty:
        return df
    df["year"] = df["year"].astype(int)
    df["employment_index"] = pd.to_numeric(df["employment_index"], errors="coerce")
    return df.dropna(subset=["employment_index"])


def degree_info_frame():
    return clean_dataframe(load_csv("degree_information.csv"))


def series_by_degree(df, value_col, key_col="degree"):
    """Return {degree: [(year, value), ...]} sorted by year."""
    out = {}
    for _, row in df.iterrows():
        out.setdefault(row[key_col], []).append((int(row["year"]), float(row[value_col])))
    for k in out:
        out[k].sort()
    return out


def rebuild_datasets():
    """Regenerate CSVs from the database (expandable data pipeline)."""
    import sys
    datasets_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datasets")
    sys.path.insert(0, datasets_dir)
    from generate_datasets import build_datasets
    return build_datasets()
