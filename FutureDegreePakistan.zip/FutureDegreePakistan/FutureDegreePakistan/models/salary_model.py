"""Salary prediction models (Linear Regression + Random Forest).

Trains one model pair per degree on the historical monthly-salary series.
The bundled historical data is SIMULATED/estimated, so predictions are
illustrative estimates, not guaranteed outcomes.
"""
import os

import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "saved_models")
SALARY_MODEL_PATH = os.path.join(MODELS_DIR, "salary_models.joblib")
EMPLOYMENT_MODEL_PATH = os.path.join(MODELS_DIR, "employment_models.joblib")


def _train_pair(X, y):
    """Train linear + RF regressors and return them with metrics."""
    X = np.asarray(X, dtype=float).reshape(-1, 1)
    y = np.asarray(y, dtype=float)

    lin = LinearRegression().fit(X, y)
    rf = RandomForestRegressor(n_estimators=100, random_state=42).fit(X, y)

    # Leave-one-out-ish evaluation via train predictions (small series).
    lin_pred = lin.predict(X)
    rf_pred = rf.predict(X)

    def metrics(pred):
        return {
            "mae": float(mean_absolute_error(y, pred)),
            "rmse": float(mean_squared_error(y, pred) ** 0.5),
            "r2": float(r2_score(y, pred)),
        }

    return {
        "linear": lin,
        "random_forest": rf,
        "metrics_linear": metrics(lin_pred),
        "metrics_rf": metrics(rf_pred),
    }


def train_salary_models(series_by_degree):
    """series_by_degree: {degree_name: list of (year, salary)}."""
    bundle = {}
    for name, rows in series_by_degree.items():
        rows = sorted(rows)
        years = [r[0] for r in rows]
        salaries = [r[1] for r in rows]
        bundle[name] = _train_pair(years, salaries)
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(bundle, SALARY_MODEL_PATH)
    return bundle


def load_salary_models():
    if not os.path.exists(SALARY_MODEL_PATH):
        return None
    return joblib.load(SALARY_MODEL_PATH)


def predict_salary(models, degree_name, year, model_type="random_forest"):
    """Return (prediction, metrics) for a degree/year or (None, None)."""
    entry = models.get(degree_name) if models else None
    if not entry:
        return None, None
    model = entry.get(model_type) or entry["linear"]
    pred = float(model.predict(np.array([[year]], dtype=float))[0])
    metrics = entry.get(f"metrics_{model_type}") or entry["metrics_linear"]
    return max(pred, 0.0), metrics
