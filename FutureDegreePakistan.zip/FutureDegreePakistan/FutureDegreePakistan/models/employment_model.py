"""Employment-demand prediction models (Linear Regression + Random Forest).

Trains one model pair per degree on the historical employment-index
series. Data is SIMULATED/estimated — predictions are illustrative.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from salary_model import MODELS_DIR, _train_pair

EMPLOYMENT_MODEL_PATH = os.path.join(MODELS_DIR, "employment_models.joblib")


def train_employment_models(series_by_degree):
    """series_by_degree: {degree_name: list of (year, employment_index)}."""
    bundle = {}
    for name, rows in series_by_degree.items():
        rows = sorted(rows)
        years = [r[0] for r in rows]
        index = [r[1] for r in rows]
        bundle[name] = _train_pair(years, index)
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(bundle, EMPLOYMENT_MODEL_PATH)
    return bundle


def load_employment_models():
    if not os.path.exists(EMPLOYMENT_MODEL_PATH):
        return None
    return joblib.load(EMPLOYMENT_MODEL_PATH)


def predict_employment(models, degree_name, year, model_type="random_forest"):
    entry = models.get(degree_name) if models else None
    if not entry:
        return None, None
    model = entry.get(model_type) or entry["linear"]
    pred = float(model.predict(np.array([[year]], dtype=float))[0])
    metrics = entry.get(f"metrics_{model_type}") or entry["metrics_linear"]
    return max(pred, 0.0), metrics
