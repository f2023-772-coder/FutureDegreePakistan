"""Train salary and employment models from the SQLite history tables.

If the DB has no history, seeds it first. Saves joblib bundles under
models/saved_models/ and prints evaluation metrics.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "database"))

from db_connection import query
from db_setup import init_database
from seed_data import seed_database
from salary_model import train_salary_models, SALARY_MODEL_PATH
from employment_model import train_employment_models, EMPLOYMENT_MODEL_PATH


def _series(sql):
    out = {}
    for r in query(sql):
        out.setdefault(r["name"], []).append((r["year"], r["value"]))
    return out


def main():
    init_database()
    seed_database()

    salary_series = _series("""
        SELECT d.name, s.year, s.avg_monthly_salary AS value
        FROM salary_history s JOIN degrees d ON d.id = s.degree_id""")
    emp_series = _series("""
        SELECT d.name, e.year, e.employment_index AS value
        FROM employment_history e JOIN degrees d ON d.id = e.degree_id""")

    salary_models = train_salary_models(salary_series)
    emp_models = train_employment_models(emp_series)

    print(f"Trained salary models for {len(salary_models)} degrees -> {SALARY_MODEL_PATH}")
    print(f"Trained employment models for {len(emp_models)} degrees -> {EMPLOYMENT_MODEL_PATH}")

    # Print a sample of metrics.
    for name in list(salary_models)[:3]:
        m = salary_models[name]
        print(f"  {name}: salary LR R2={m['metrics_linear']['r2']:.3f} "
              f"RF R2={m['metrics_rf']['r2']:.3f}")


if __name__ == "__main__":
    main()
