"""Matplotlib chart builders. Each returns a Figure to embed in CTk."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from helpers import COLORS

CHART_COLORS = ["#1B3A6B", "#3B82F6", "#60A5FA", "#93C5FD", "#2563EB",
                "#1E40AF", "#7DD3FC", "#0EA5E9", "#1D4ED8", "#38BDF8"]

plt.rcParams.update({
    "font.size": 9,
    "axes.edgecolor": "#CBD5E1",
    "axes.labelcolor": "#374151",
    "xtick.color": "#6B7280",
    "ytick.color": "#6B7280",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})


def _style(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis="y", linestyle="--", alpha=0.4)


def bar_chart(labels, values, title, ylabel="Value", figsize=(6, 3.5),
              color=CHART_COLORS[0], horizontal=False):
    fig, ax = plt.subplots(figsize=figsize)
    if horizontal:
        ax.barh(labels, values, color=color)
        ax.invert_yaxis()
    else:
        ax.bar(labels, values, color=color)
        plt.xticks(rotation=45, ha="right", fontsize=7)
    ax.set_title(title, fontsize=11, fontweight="bold", color=COLORS["primary"])
    ax.set_ylabel(ylabel)
    _style(ax)
    fig.tight_layout()
    return fig


def line_chart(years, series_map, title, ylabel="Value", figsize=(6, 3.5)):
    """series_map: {label: [values]}."""
    fig, ax = plt.subplots(figsize=figsize)
    for i, (label, values) in enumerate(series_map.items()):
        ax.plot(years, values, marker="o", markersize=3, linewidth=1.8,
                color=CHART_COLORS[i % len(CHART_COLORS)], label=label)
    ax.set_title(title, fontsize=11, fontweight="bold", color=COLORS["primary"])
    ax.set_ylabel(ylabel)
    ax.legend(fontsize=8)
    _style(ax)
    fig.tight_layout()
    return fig


def pie_chart(labels, values, title, figsize=(4, 3.5)):
    fig, ax = plt.subplots(figsize=figsize)
    colors = CHART_COLORS[:len(labels)]
    ax.pie(values, labels=labels, autopct="%1.0f%%", colors=colors,
           startangle=90, textprops={"fontsize": 8})
    ax.set_title(title, fontsize=11, fontweight="bold", color=COLORS["primary"])
    fig.tight_layout()
    return fig


def multi_bar_chart(labels, datasets, title, ylabel="Value", figsize=(7, 3.5)):
    """datasets: {series_label: [values aligned to labels]}."""
    import numpy as np
    fig, ax = plt.subplots(figsize=figsize)
    x = np.arange(len(labels))
    n = len(datasets)
    width = 0.8 / max(n, 1)
    for i, (label, values) in enumerate(datasets.items()):
        ax.bar(x + i * width - (n - 1) * width / 2, values, width,
               label=label, color=CHART_COLORS[i % len(CHART_COLORS)])
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=7)
    ax.set_title(title, fontsize=11, fontweight="bold", color=COLORS["primary"])
    ax.set_ylabel(ylabel)
    ax.legend(fontsize=8)
    _style(ax)
    fig.tight_layout()
    return fig


def salary_projection_chart(hist_years, hist_salaries, proj, title,
                            figsize=(6, 3.5)):
    """hist: past salary series; proj: [{'year','salary'}] future."""
    fig, ax = plt.subplots(figsize=figsize)
    ax.plot(hist_years, hist_salaries, marker="o", markersize=4,
            color=CHART_COLORS[0], label="Historical")
    if proj:
        px = [p["year"] for p in proj]
        py = [p["salary"] for p in proj]
        ax.plot(px, py, marker="o", markersize=4, linestyle="--",
                color=CHART_COLORS[1], label="Projected")
    ax.set_title(title, fontsize=11, fontweight="bold", color=COLORS["primary"])
    ax.set_ylabel("PKR / month")
    ax.legend(fontsize=8)
    _style(ax)
    fig.tight_layout()
    return fig


def embed_figure(parent, fig, height=280):
    """Embed a matplotlib Figure into a CustomTkinter parent."""
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()
    canvas.get_tk_widget().pack(fill="both", expand=True)
    return canvas
