"""Shared helpers: paths, formatting, colors."""
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for sub in ["database", "models", "services", "utils", "ui"]:
    p = os.path.join(BASE_DIR, sub)
    if p not in sys.path:
        sys.path.insert(0, p)

# Color scheme: dark blue / white / light blue
COLORS = {
    "primary": "#1B3A6B",        # dark blue
    "primary_dark": "#12294A",
    "accent": "#3B82F6",         # light blue
    "accent_soft": "#DBEAFE",
    "bg": "#F4F7FB",             # page background
    "card": "#FFFFFF",
    "text": "#1F2937",
    "muted": "#6B7280",
    "success": "#16A34A",
    "warning": "#D97706",
    "danger": "#DC2626",
}


def format_pkr(amount):
    """Format a number as PKR with commas."""
    if amount is None:
        return "—"
    try:
        return f"PKR {int(round(amount)):,}"
    except (TypeError, ValueError):
        return str(amount)


def format_pkr_short(amount):
    if amount is None:
        return "—"
    try:
        v = float(amount)
        if abs(v) >= 100000:
            return f"PKR {v/100000:.1f}L"
        if abs(v) >= 1000:
            return f"PKR {v/1000:.0f}K"
        return f"PKR {v:,.0f}"
    except (TypeError, ValueError):
        return str(amount)
