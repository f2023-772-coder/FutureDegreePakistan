"""Generate dataset CSVs from the seeded database.

The historical series stored in the database are SIMULATED illustrative
estimates (see database/seed_data.py). The generated CSVs carry the same
data_source='estimated' label so nothing is presented as official
Pakistani employment statistics.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "database"))
import pandas as pd
from db_connection import query
from db_setup import init_database
from seed_data import seed_database

HERE = os.path.dirname(os.path.abspath(__file__))


def build_datasets():
    init_database()
    seed_database()

    salary = query("""
        SELECT d.name AS degree, s.year, s.avg_monthly_salary AS salary_pkr,
               s.data_source
        FROM salary_history s JOIN degrees d ON d.id = s.degree_id
        ORDER BY d.name, s.year""")
    pd.DataFrame(salary).to_csv(os.path.join(HERE, "salary_data.csv"), index=False)

    employment = query("""
        SELECT d.name AS degree, e.year, e.employment_index, e.job_openings_est,
               e.data_source
        FROM employment_history e JOIN degrees d ON d.id = e.degree_id
        ORDER BY d.name, e.year""")
    pd.DataFrame(employment).to_csv(os.path.join(HERE, "employment_data.csv"), index=False)

    degrees = query("""
        SELECT d.name, d.category, d.description, d.duration, d.salary_band,
               d.demand_index, d.growth_rate,
               (SELECT GROUP_CONCAT(subject_name, '; ') FROM subjects s
                 WHERE s.degree_id = d.id) AS subjects
        FROM degrees d ORDER BY d.name""")
    pd.DataFrame(degrees).to_csv(os.path.join(HERE, "degree_information.csv"), index=False)

    return True


if __name__ == "__main__":
    build_datasets()
    print("Datasets written to", HERE)
