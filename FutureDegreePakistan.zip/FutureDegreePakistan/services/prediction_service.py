"""Career prediction service.

Combines the SQLite history tables, the trained joblib models, and the
CSV datasets into career prediction reports. All outputs are labelled
as estimates — the underlying historical series are simulated/illustrative
and predictions are not guaranteed.
"""
import os
import sys
import json
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE_DIR, "database"))
sys.path.insert(0, os.path.join(BASE_DIR, "models"))
sys.path.insert(0, os.path.join(BASE_DIR, "services"))

from db_connection import query, execute
from db_setup import init_database
from seed_data import seed_database
import salary_model
import employment_model
import data_processing
import spark_service

CURRENT_YEAR = datetime.now().year
DATA_NOTE = ("Illustrative estimate based on simulated historical data. "
             "Not an official Pakistani employment statistic and not a guarantee.")

_salary_models = None
_emp_models = None
_models_loaded = False
_spark_models_ok = False
_spark = None


def _ensure_spark():
    """Lazily start Spark and ensure MLlib models exist. Returns SparkSession or None."""
    global _spark, _spark_models_ok
    if _spark_models_ok and _spark is not None:
        return _spark
    _spark = spark_service.get_spark()
    if _spark is None:
        return None
    # Fill in any missing/incomplete models (skips complete ones quickly).
    try:
        spark_service.train_spark_models(_spark, force=False)
    except Exception:
        pass
    _spark_models_ok = True
    return _spark


def _spark_predict(kind, degree_name, target_year):
    """Predict via Spark MLlib. Returns (salary, employment) or (None, None)."""
    spark = _ensure_spark()
    if spark is None:
        return None, None
    try:
        sal = spark_service.predict_salary(spark, degree_name, target_year, kind)
        emp = spark_service.predict_employment(spark, degree_name, target_year, kind)
        return sal, emp
    except Exception:
        return None, None


def _ensure_ready():
    """Init DB, seed if empty, and load (or train) models once."""
    global _salary_models, _emp_models, _models_loaded
    init_database()
    seed_database()
    if not _models_loaded:
        _salary_models = salary_model.load_salary_models()
        _emp_models = employment_model.load_employment_models()
        if _salary_models is None or _emp_models is None:
            _retrain_models()
        _models_loaded = True


def _retrain_models():
    """Train models from the CSV datasets (expandable data source)."""
    global _salary_models, _emp_models
    try:
        df_s = data_processing.salary_frame()
        df_e = data_processing.employment_frame()
        if not df_s.empty:
            _salary_models = salary_model.train_salary_models(
                data_processing.series_by_degree(df_s, "salary_pkr"))
        if not df_e.empty:
            _emp_models = employment_model.train_employment_models(
                data_processing.series_by_degree(df_e, "employment_index"))
    except Exception:
        # Fall back to training straight from the database history.
        salary_series = {}
        for r in query("""SELECT d.name, s.year, s.avg_monthly_salary v
                          FROM salary_history s JOIN degrees d ON d.id=s.degree_id"""):
            salary_series.setdefault(r["name"], []).append((r["year"], r["v"]))
        emp_series = {}
        for r in query("""SELECT d.name, e.year, e.employment_index v
                          FROM employment_history e JOIN degrees d ON d.id=e.degree_id"""):
            emp_series.setdefault(r["name"], []).append((r["year"], r["v"]))
        _salary_models = salary_model.train_salary_models(salary_series)
        _emp_models = employment_model.train_employment_models(emp_series)


def list_degrees():
    _ensure_ready()
    return query("SELECT * FROM degrees ORDER BY name")


def get_degree(name):
    _ensure_ready()
    rows = query("SELECT * FROM degrees WHERE name=?", (name,))
    return rows[0] if rows else None


def degree_details(name):
    """Full degree profile: degree row plus all related collections."""
    degree = get_degree(name)
    if not degree:
        return None
    did = degree["id"]
    return {
        "degree": degree,
        "subjects": query("SELECT subject_name FROM subjects WHERE degree_id=?", (did,)),
        "skills": query("SELECT * FROM skills WHERE degree_id=? ORDER BY importance DESC", (did,)),
        "careers": query("SELECT * FROM careers WHERE degree_id=? ORDER BY job_positions DESC", (did,)),
        "industries": query("SELECT industry_name FROM industries WHERE degree_id=?", (did,)),
        "certifications": query("SELECT cert_name FROM certifications WHERE degree_id=?", (did,)),
        "challenges": query("SELECT challenge FROM challenges WHERE degree_id=?", (did,)),
        "salary_history": query("SELECT year, avg_monthly_salary FROM salary_history WHERE degree_id=? ORDER BY year", (did,)),
        "employment_history": query("SELECT year, employment_index, job_openings_est FROM employment_history WHERE degree_id=? ORDER BY year", (did,)),
    }


def _latest_history(details, key, value_col):
    hist = details[key]
    if not hist:
        return None
    return hist[-1][value_col]


def predict_career(degree_name, years_ahead, model_type="random_forest"):
    """Generate a prediction report for degree_name `years_ahead` years out."""
    _ensure_ready()
    details = degree_details(degree_name)
    if not details:
        raise ValueError(f"Unknown degree: {degree_name}")

    years_ahead = int(years_ahead)
    if not (1 <= years_ahead <= 10):
        raise ValueError("Prediction period must be between 1 and 10 years")

    target_year = CURRENT_YEAR + years_ahead
    degree = details["degree"]

    # Primary engine: Spark MLlib (per-degree LinearRegression /
    # RandomForestRegressor trained on the CSV datasets via Spark).
    spark_kind = "rf" if model_type == "random_forest" else "linear"
    sp_sal, sp_emp = _spark_predict(spark_kind, degree_name, target_year)

    engine = "scikit-learn"
    if sp_sal is not None and sp_emp is not None:
        pred_salary, pred_emp = sp_sal, sp_emp
        engine = f"pyspark-mllib ({spark_kind})"
        salary_metrics = spark_service.get_metrics("salary", degree_name, spark_kind)
        emp_metrics = spark_service.get_metrics("employment", degree_name, spark_kind)
        alt_kind = "linear" if spark_kind == "rf" else "rf"
        alt_salary = spark_service.predict_salary(_spark, degree_name, target_year, alt_kind)
        alt_emp = spark_service.predict_employment(_spark, degree_name, target_year, alt_kind)
        alt_model = f"pyspark-mllib ({alt_kind})"
    else:
        # Compute both model predictions; Random Forest saturates outside
        # the training range, while Linear Regression extrapolates the trend.
        pred_salary, salary_metrics = salary_model.predict_salary(
            _salary_models, degree_name, target_year, model_type)
        pred_emp, emp_metrics = employment_model.predict_employment(
            _emp_models, degree_name, target_year, model_type)
        alt_salary, _ = salary_model.predict_salary(
            _salary_models, degree_name, target_year,
            "linear" if model_type == "random_forest" else "random_forest")
        alt_emp, _ = employment_model.predict_employment(
            _emp_models, degree_name, target_year,
            "linear" if model_type == "random_forest" else "random_forest")
        alt_model = ("scikit-learn (linear)" if model_type == "random_forest"
                     else "scikit-learn (random_forest)")

    current_salary = _latest_history(details, "salary_history", "avg_monthly_salary")
    current_emp = _latest_history(details, "employment_history", "employment_index")

    # If model produced nothing, fall back to linear extrapolation from history.
    if pred_salary is None and current_salary:
        growth = float(degree["growth_rate"] or 0.05)
        pred_salary = current_salary * ((1 + growth) ** years_ahead)
    if pred_emp is None and current_emp:
        growth = float(degree["growth_rate"] or 0.05)
        pred_emp = current_emp * ((1 + growth * 0.8) ** years_ahead)

    salary_growth_pct = None
    if pred_salary and current_salary:
        salary_growth_pct = (pred_salary - current_salary) / current_salary * 100
    emp_growth_pct = None
    if pred_emp and current_emp:
        emp_growth_pct = (pred_emp - current_emp) / current_emp * 100

    metrics_json = json.dumps({
        "salary": salary_metrics, "employment": emp_metrics,
        "model_type": model_type, "engine": engine,
        "trained_on": "simulated historical series",
    })

    report = {
        "degree": degree_name,
        "category": degree["category"],
        "current_year": CURRENT_YEAR,
        "period_years": years_ahead,
        "target_year": target_year,
        "predicted_salary_pkr": round(pred_salary, -2) if pred_salary else None,
        "current_salary_pkr": current_salary,
        "salary_growth_pct": round(salary_growth_pct, 1) if salary_growth_pct is not None else None,
        "predicted_employment_index": round(pred_emp, 2) if pred_emp else None,
        "employment_growth_pct": round(emp_growth_pct, 1) if emp_growth_pct is not None else None,
        "job_demand_level": _demand_label(degree["demand_index"]),
        "career_opportunities": [c["job_title"] for c in details["careers"]],
        "industries": [i["industry_name"] for i in details["industries"]],
        "future_skills": [s["skill_name"] for s in details["skills"] if s["skill_type"] == "technical"][:5],
        "challenges": [c["challenge"] for c in details["challenges"]],
        "certifications": [c["cert_name"] for c in details["certifications"]],
        "salary_metrics": salary_metrics,
        "employment_metrics": emp_metrics,
        "alt_salary_prediction": round(alt_salary, -2) if alt_salary else None,
        "alt_employment_prediction": round(alt_emp, 2) if alt_emp else None,
        "alt_model_type": alt_model,
        "model_type": model_type,
        "engine": engine,
        "data_note": DATA_NOTE,
        "salary_history": details["salary_history"],
        "employment_history": details["employment_history"],
    }

    # Persist the report.
    execute(
        """INSERT INTO predictions (degree_id, target_year, predicted_salary,
               predicted_employment, salary_growth_pct, employment_growth_pct,
               model_used, metrics_json)
           VALUES (?,?,?,?,?,?,?,?)""",
        (degree["id"], target_year, report["predicted_salary_pkr"],
         report["predicted_employment_index"], report["salary_growth_pct"],
         report["employment_growth_pct"], model_type, metrics_json))

    return report


def _demand_label(demand_index):
    d = float(demand_index or 5)
    if d >= 8.5:
        return "Very High"
    if d >= 7:
        return "High"
    if d >= 5.5:
        return "Moderate"
    return "Developing"


def salary_projection(degree_name, max_years=10):
    """Return yearly salary projection list for charts."""
    details = degree_details(degree_name)
    if not details:
        return []
    current_salary = _latest_history(details, "salary_history", "avg_monthly_salary")
    degree = details["degree"]
    if not current_salary:
        return []
    growth = float(degree["growth_rate"] or 0.05)
    proj = []
    for y in range(1, max_years + 1):
        proj.append({
            "year": CURRENT_YEAR + y,
            "salary": round(current_salary * ((1 + growth) ** y), -2),
        })
    return proj


def compare_degrees(names):
    """Return comparison rows for up to 3 degrees."""
    _ensure_ready()
    rows = []
    for name in names:
        details = degree_details(name)
        if not details:
            continue
        d = details["degree"]
        cur_sal = _latest_history(details, "salary_history", "avg_monthly_salary") or 0
        # 5-year projected salary/employment — Spark MLlib first, sklearn fallback.
        sp_sal, sp_emp = _spark_predict("linear", name, CURRENT_YEAR + 5)
        if sp_sal is not None:
            proj_sal = sp_sal
        else:
            proj = salary_model.predict_salary(_salary_models, name, CURRENT_YEAR + 5, "linear")
            proj_sal = proj[0] if proj[0] else cur_sal
        emp_now = _latest_history(details, "employment_history", "employment_index") or 0
        if sp_emp is not None:
            emp_proj = sp_emp
        else:
            emp_pred = employment_model.predict_employment(_emp_models, name, CURRENT_YEAR + 5, "linear")
            emp_proj = emp_pred[0] if emp_pred[0] else emp_now
        rows.append({
            "name": name,
            "category": d["category"],
            "current_salary": cur_sal,
            "projected_salary_5y": round(proj_sal, -2),
            "salary_growth_5y_pct": round((proj_sal - cur_sal) / cur_sal * 100, 1) if cur_sal else 0,
            "demand_index": d["demand_index"],
            "employment_index_now": round(emp_now, 1),
            "employment_index_5y": round(emp_proj, 1),
            "employment_growth_pct": round((emp_proj - emp_now) / emp_now * 100, 1) if emp_now else 0,
            "top_careers": ", ".join(c["job_title"] for c in details["careers"][:3]),
            "top_industries": ", ".join(i["industry_name"] for i in details["industries"][:3]),
            "key_skills": ", ".join(s["skill_name"] for s in details["skills"][:4]),
            "job_positions_total": sum(c["job_positions"] for c in details["careers"]),
        })
    return rows


def salary_analysis():
    """Salary table for all degrees: starting/avg/experienced + growth."""
    _ensure_ready()
    rows = []
    for d in query("SELECT * FROM degrees ORDER BY name"):
        det = degree_details(d["name"])
        hist = det["salary_history"]
        if not hist:
            continue
        first, last = hist[0]["avg_monthly_salary"], hist[-1]["avg_monthly_salary"]
        proj = salary_projection(d["name"], 10)
        rows.append({
            "name": d["name"],
            "category": d["category"],
            "starting_salary": first,
            "current_salary": last,
            "salary_10y": proj[-1]["salary"] if proj else last,
            "growth_pct": round((proj[-1]["salary"] - last) / last * 100, 1) if proj else 0,
            "salary_band": d["salary_band"],
        })
    return rows


def market_trends():
    """Aggregate employment/salary trends across all degrees.

    Uses Spark SQL over the CSV datasets when PySpark is available,
    otherwise falls back to SQLite aggregations.
    """
    _ensure_ready()
    # Category-level demand (always from SQLite degree metadata).
    cats = query("""SELECT category, AVG(demand_index) avg_demand, AVG(growth_rate) avg_growth
                    FROM degrees GROUP BY category ORDER BY avg_demand DESC""")

    spark = _ensure_spark()
    if spark is not None:
        try:
            s = spark_service.spark_sql_summary(spark)
            emp = [{"year": r["year"], "avg_emp": r.get("avg_index"),
                    "openings": r.get("openings", 0)} for r in s["employment_by_year"]]
            sal = [{"year": r["year"], "avg_salary": r["avg_salary"]}
                   for r in s["salary_by_year"]]
            return {"employment": emp, "salary": sal, "categories": cats,
                    "engine": "pyspark-sql", "note": DATA_NOTE}
        except Exception:
            pass

    # SQLite fallback.
    emp = query("""SELECT year, AVG(employment_index) avg_emp, SUM(job_openings_est) openings
                   FROM employment_history GROUP BY year ORDER BY year""")
    sal = query("""SELECT year, AVG(avg_monthly_salary) avg_salary
                   FROM salary_history GROUP BY year ORDER BY year""")
    return {"employment": emp, "salary": sal, "categories": cats,
            "engine": "sqlite", "note": DATA_NOTE}


def recent_predictions(limit=10):
    _ensure_ready()
    return query("""SELECT p.*, d.name AS degree_name FROM predictions p
                    JOIN degrees d ON d.id = p.degree_id
                    ORDER BY p.id DESC LIMIT ?""", (limit,))
