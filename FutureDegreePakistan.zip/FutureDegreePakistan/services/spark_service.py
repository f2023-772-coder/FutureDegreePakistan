"""PySpark engine for FutureDegree Pakistan.

Responsibilities:
  - Lazy SparkSession management (local mode, offline).
  - Load the CSV datasets into Spark DataFrames and clean them.
  - Execute Spark SQL queries for aggregation/analytics.
  - Train per-degree salary & employment models with Spark MLlib
    (LinearRegression + RandomForestRegressor) and evaluate them
    (MAE / RMSE / R^2 via RegressionEvaluator).
  - Persist trained models and serve predictions through MLlib.

All historical data is simulated/illustrative (see datasets/), so
predictions remain estimates, not guarantees.
"""
import os
import re
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE_DIR, "utils"))
sys.path.insert(0, os.path.join(BASE_DIR, "services"))

DATASETS_DIR = os.path.join(BASE_DIR, "datasets")
SPARK_MODELS_DIR = os.path.join(BASE_DIR, "models", "saved_models", "spark")

_spark = None
_spark_failed = False


def spark_available():
    """True if pyspark imports successfully."""
    try:
        import pyspark  # noqa: F401
        return True
    except Exception:
        return False


def get_spark():
    """Return a shared SparkSession (created lazily, local mode)."""
    global _spark, _spark_failed
    if _spark is not None:
        return _spark
    if _spark_failed or not spark_available():
        return None
    try:
        # Windows + PySpark needs Hadoop native shims (winutils.exe) for
        # local file writes. A bundled copy lives in <project>/hadoop.
        hadoop_home = os.path.join(BASE_DIR, "hadoop")
        if os.path.exists(os.path.join(hadoop_home, "bin", "winutils.exe")):
            os.environ.setdefault("HADOOP_HOME", hadoop_home)
            os.environ.setdefault("hadoop.home.dir", hadoop_home)
            # Forward slashes survive JVM option parsing (backslashes get
            # eaten as escape characters in JAVA_TOOL_OPTIONS).
            lib_path = os.path.join(hadoop_home, "bin").replace("\\", "/")
            # JAVA_TOOL_OPTIONS is picked up by every JVM launched after this,
            # including the PySpark gateway JVM (more reliable than
            # spark.driver.extraJavaOptions in local mode).
            os.environ["JAVA_TOOL_OPTIONS"] = (
                f'-Djava.library.path="{lib_path}" '
                + os.environ.get("JAVA_TOOL_OPTIONS", "")
            ).strip()
            jvm_opts = f'-Djava.library.path="{lib_path}"'
        else:
            jvm_opts = ""

        # Ensure Spark's Python worker uses this exact interpreter.
        # Use the 8.3 short path: the real path contains a space
        # ("Daniyal Shafaqat") which breaks Spark's cmd-based worker
        # launch on Windows ("where" / unquoted args -> dead worker
        # -> Connection reset in PythonAccumulatorV2/PythonRunner).
        py = _short_path(sys.executable)
        os.environ["PYSPARK_PYTHON"] = py
        os.environ["PYSPARK_DRIVER_PYTHON"] = py

        from pyspark.sql import SparkSession
        _spark = (
            SparkSession.builder
            .master("local[2]")
            .appName("FutureDegreePakistan")
            .config("spark.driver.host", "localhost")
            .config("spark.driver.bindAddress", "127.0.0.1")
            .config("spark.sql.shuffle.partitions", "2")
            .config("spark.ui.enabled", "false")
            .config("spark.python.worker.reuse", "false")
            .config("spark.driver.extraJavaOptions", jvm_opts)
            .config("spark.executor.extraJavaOptions", jvm_opts)
            .getOrCreate()
        )
        _spark.sparkContext.setLogLevel("WARN")
        return _spark
    except Exception:
        _spark_failed = True
        return None


def stop_spark():
    global _spark
    if _spark is not None:
        try:
            _spark.stop()
        except Exception:
            pass
        _spark = None


# ------------------------------------------------------------------
# Spark DataFrame loading & cleaning
# ------------------------------------------------------------------
def _read_csv(spark, filename):
    path = os.path.join(DATASETS_DIR, filename)
    return spark.read.csv(path, header=True, inferSchema=True)


def clean_sdf(df):
    """Spark equivalent of pandas cleaning: drop nulls + duplicates."""
    return df.dropna().dropDuplicates()


def salary_sdf(spark):
    """Cleaned salary Spark DataFrame with columns (degree, year, value)."""
    df = _read_csv(spark, "salary_data.csv")
    df = clean_sdf(df).select(
        "degree",
        df["year"].cast("int").alias("year"),
        df["salary_pkr"].cast("double").alias("value"),
    )
    return df.filter("value IS NOT NULL")


def employment_sdf(spark):
    """Cleaned employment Spark DataFrame (degree, year, value, openings)."""
    df = _read_csv(spark, "employment_data.csv")
    df = clean_sdf(df).select(
        "degree",
        df["year"].cast("int").alias("year"),
        df["employment_index"].cast("double").alias("value"),
        df["job_openings_est"].cast("bigint").alias("job_openings_est"),
    )
    return df.filter("value IS NOT NULL")


def degree_sdf(spark):
    return clean_sdf(_read_csv(spark, "degree_information.csv"))


# ------------------------------------------------------------------
# Spark SQL layer (temp views + real SQL queries)
# ------------------------------------------------------------------
def register_views(spark):
    """Expose the cleaned frames as SQL temp views."""
    salary_sdf(spark).createOrReplaceTempView("salary_data")
    employment_sdf(spark).createOrReplaceTempView("employment_data")
    degree_sdf(spark).createOrReplaceTempView("degree_info")


def spark_sql_summary(spark):
    """Run Spark SQL aggregations; returns dict of pandas-friendly rows."""
    register_views(spark)
    out = {}
    out["salary_by_year"] = spark.sql(
        "SELECT year, ROUND(AVG(value),0) AS avg_salary FROM salary_data "
        "GROUP BY year ORDER BY year").toPandas().to_dict("records")
    out["top_salaries"] = spark.sql(
        "SELECT degree, ROUND(AVG(value),0) AS avg_salary FROM salary_data "
        "GROUP BY degree ORDER BY avg_salary DESC LIMIT 10").toPandas().to_dict("records")
    out["employment_by_year"] = spark.sql(
        "SELECT year, ROUND(AVG(value),2) AS avg_index, "
        "SUM(job_openings_est) AS openings "
        "FROM employment_data GROUP BY year ORDER BY year"
    ).toPandas().to_dict("records")
    out["degree_count"] = spark.sql(
        "SELECT COUNT(*) AS c FROM degree_info").first()["c"]
    return out


# ------------------------------------------------------------------
# MLlib training & prediction
# ------------------------------------------------------------------
def _safe(name):
    return re.sub(r"[^A-Za-z0-9_]+", "_", name)


def _short_path(path):
    """Return the Windows 8.3 short path (no spaces) if available."""
    try:
        import ctypes
        buf = ctypes.create_unicode_buffer(260)
        if ctypes.windll.kernel32.GetShortPathNameW(str(path), buf, 260):
            short = buf.value
            if short:
                return short
    except Exception:
        pass
    return str(path)


def _degree_names(sdf):
    return [r["degree"] for r in
            sdf.select("degree").distinct().orderBy("degree").collect()]


def _train_one(df, ModelClass, out_dir, label="value"):
    """Train a single MLlib regressor on (year -> value); save + metrics."""
    from pyspark.ml.feature import VectorAssembler
    from pyspark.ml.evaluation import RegressionEvaluator

    va = VectorAssembler(inputCols=["year"], outputCol="features")
    data = va.transform(df)
    model = ModelClass(labelCol=label, featuresCol="features",
                       predictionCol="pred").fit(data)
    pred = model.transform(data)
    ev = RegressionEvaluator(labelCol=label, predictionCol="pred")
    metrics = {
        "mae": ev.setMetricName("mae").evaluate(pred),
        "rmse": ev.setMetricName("rmse").evaluate(pred),
        "r2": ev.setMetricName("r2").evaluate(pred),
    }
    os.makedirs(os.path.dirname(out_dir), exist_ok=True)
    model.write().overwrite().save(out_dir)
    import json
    with open(out_dir + "_metrics.json", "w") as f:
        json.dump(metrics, f)
    return metrics


def train_spark_models(spark=None, force=False):
    """Train per-degree MLlib models for salary & employment.

    Returns a dict {target: {degree: {"linear": metrics, "rf": metrics}}}.
    Models are saved under models/saved_models/spark/{target}/{degree}/.
    """
    spark = spark or get_spark()
    if spark is None:
        return None

    summary = {}
    for target, sdf_fn, fname in [
        ("salary", salary_sdf, "salary_models"),
        ("employment", employment_sdf, "employment_models"),
    ]:
        sdf = sdf_fn(spark)
        names = _degree_names(sdf)
        summary[target] = {}
        for name in names:
            ddf = sdf.filter(f"degree = '{name.replace(chr(39), chr(39)*2)}'")
            base = os.path.join(SPARK_MODELS_DIR, fname, _safe(name))
            entry = {}
            if force or not _model_complete(os.path.join(base, "linear")):
                from pyspark.ml.regression import LinearRegression
                entry["linear"] = _train_one(ddf, LinearRegression,
                                             os.path.join(base, "linear"))
            if force or not _model_complete(os.path.join(base, "rf")):
                from pyspark.ml.regression import RandomForestRegressor
                entry["rf"] = _train_one(ddf, RandomForestRegressor,
                                         os.path.join(base, "rf"))
            summary[target][name] = entry
    return summary


def _model_dir(target, degree, kind):
    fname = "salary_models" if target == "salary" else "employment_models"
    return os.path.join(SPARK_MODELS_DIR, fname, _safe(degree), kind)


def _model_complete(path):
    """A saved MLlib model is only usable if metadata + data exist."""
    return (os.path.isdir(path)
            and os.path.exists(os.path.join(path, "metadata"))
            and os.path.exists(os.path.join(path, "data")))


def _predict_with(spark, target, degree, year, kind):
    """Load a saved MLlib model and predict `value` for `year`."""
    path = _model_dir(target, degree, kind)
    if not _model_complete(path):
        return None
    from pyspark.ml.feature import VectorAssembler
    from pyspark.ml.regression import (LinearRegressionModel,
                                       RandomForestRegressionModel)

    if kind == "linear":
        model = LinearRegressionModel.load(path)
    else:
        model = RandomForestRegressionModel.load(path)

    pdf = spark.createDataFrame([(int(year),)], ["year"])
    va = VectorAssembler(inputCols=["year"], outputCol="features")
    data = va.transform(pdf)
    pred = model.transform(data).select("pred").first()
    return float(pred["pred"]) if pred else None


def spark_models_exist(target=None):
    """True if at least one complete MLlib model is saved."""
    targets = [target] if target else ["salary", "employment"]
    for t in targets:
        fname = "salary_models" if t == "salary" else "employment_models"
        root = os.path.join(SPARK_MODELS_DIR, fname)
        if not os.path.isdir(root):
            continue
        for deg in os.listdir(root):
            for kind in ("linear", "rf"):
                if _model_complete(os.path.join(root, deg, kind)):
                    return True
    return False


def predict_salary(spark, degree, year, kind="linear"):
    return _predict_with(spark, "salary", degree, year, kind)


def predict_employment(spark, degree, year, kind="linear"):
    return _predict_with(spark, "employment", degree, year, kind)


def get_metrics(target, degree, kind):
    """Load saved evaluation metrics for a trained Spark model."""
    import json
    path = _model_dir(target, degree, kind) + "_metrics.json"
    if not os.path.exists(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None


def spark_engine_status():
    """Status dict for Settings/UI display."""
    return {
        "available": spark_available(),
        "session": get_spark() is not None,
        "models_trained": spark_models_exist(),
    }
